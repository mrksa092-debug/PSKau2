import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export const getNouraResponse = async (prompt: string, patientData: any) => {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `
    أنتِ "نورة"، مساعدة ذكية متخصصة في متابعة الحمل لمستخدمات تطبيق "رحلة الأمومة".
    بيانات الأم الحالية:
    - الاسم: ${patientData.name}
    - رقم الملف: ${patientData.fileNumber}
    - تاريخ بدء الحمل: ${patientData.pregnancyStartDate}
    - فصيلة الدم: ${patientData.bloodType}
    - المستشفى: ${patientData.hospitalName}
    - نتائج التحاليل: ${JSON.stringify(patientData.labResults)}
    - الأدوية: ${JSON.stringify(patientData.medications)}
    - سجل المواعيد (التقارير): ${JSON.stringify(patientData.medicalReports.map((r: any) => ({ title: r.title, date: r.date, summary: r.summary, status: r.status })))}

    مهامكِ:
    1. الإجابة على استفسارات الأم بخصوص حالتها بناءً على البيانات المتوفرة وسجل المواعيد السابق.
    2. حساب عدد الأسابيع المتبقية للولادة بدقة (الحمل الطبيعي 40 أسبوعاً).
    3. شرح نتائج المختبر بشكل مبسط ومطمئن وشرح ما حدث في المواعيد السابقة إذا سألت الأم.
    4. تقديم نصائح مناسبة للأسبوع الحالي من الحمل.
    5. تنبيه الأم لضرورة استشارة الطبيب في حال وجود أعراض خطيرة.
    
    أسلوبكِ:
    - ودود، حنون، ومطمئن.
    - استخدمي اللغة العربية الفصحى المبسطة أو اللهجة السعودية البيضاء بشكل مهذب.
    - لا تقدمي تشخيصات طبية نهائية، بل قولي "بناءً على نتائجك المرفوعة..." وانصحي دائماً بالمتابعة مع الطبيب.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        systemInstruction,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Gemini AI Error:", error);
    return "عذراً، أواجه صعوبة في الاتصال حالياً. حاولي مرة أخرى لاحقاً.";
  }
};
