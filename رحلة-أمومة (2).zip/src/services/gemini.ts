import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });

export async function* streamChat(message: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) {
  const model = "gemini-3-flash-preview";
  
  const chat = ai.chats.create({
    model,
    config: {
      systemInstruction: `أنت مساعد ذكي ومتخصص في متابعة الحمل لمساعدة الأمهات. 
      اسمك "مساعد رحلة أمومة". تقديم نصائح طبية، نفسية، وغذائية. 
      دائماً ذكر الأم بضرورة استشارة طبيبها الخاص للحالات الطارئة. 
      تحدث باللغة العربية بلهجة ودودة وداعمة.`
    }
  });

  // Since ai.chats doesn't strictly support history in this simple SDK the same way, 
  // we can pass current context or use a stateless generateContent if preferred.
  // Actually, Gemini SDK supports sendMessageStream.
  
  const result = await chat.sendMessageStream({ message });

  for await (const chunk of result) {
    if (chunk.text) {
      yield chunk.text;
    }
  }
}
