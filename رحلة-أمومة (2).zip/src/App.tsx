import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import AIAssistant from './components/AIAssistant';
import Footer from './components/Footer';
import { Loader2 } from 'lucide-react';

function AppContent() {
  const { user, patient, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#fffafb]">
        <Loader2 className="animate-spin text-brand-500 w-12 h-12" />
      </div>
    );
  }

  if (!patient) {
    return <Login />;
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Dashboard />
      <AIAssistant />
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}



