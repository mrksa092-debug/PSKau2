import { Apple, HeartPulse, Brain, Utensils } from 'lucide-react';

const tips = [
  {
    icon: <Apple className="text-orange-500" />,
    title: "التغذية السليمة",
    description: "ركزي على الأطعمة الغنية بالحديد والكالسيوم وحمض الفوليك. الخضروات الورقية والبروتينات ضرورية جداً.",
    color: "bg-orange-50"
  },
  {
    icon: <HeartPulse className="text-brand-500" />,
    title: "النشاط البدني",
    description: "المشي الخفيف واليوغا المخصصة للحوامل يساعدان في تقليل التوتر وتحسين الدورة الدموية.",
    color: "bg-pink-50"
  },
  {
    icon: <Brain className="text-purple-500" />,
    title: "الصحة النفسية",
    description: "خصصي وقتاً للاسترخاء والتأمل. صحتكِ النفسية تنعكس مباشرة على نمو جنينكِ وراحتكِ.",
    color: "bg-purple-50"
  },
  {
    icon: <Utensils className="text-blue-500" />,
    title: "ترطيب الجسم",
    description: "اشربي ما لا يقل عن 8-10 أكواب من الماء يومياً لتجنب الجفاف وتقليل التورم.",
    color: "bg-blue-50"
  }
];

export default function Tips({ onContactClick }: { onContactClick?: () => void }) {
  return (
    <section id="tips" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">نصائح لصحتكِ وجمالكِ</h2>
          <p className="text-gray-500">مجموعة من النصائح المختارة بعناية لتمر رحلة حملكِ بسلام وسعادة.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {tips.map((tip, index) => (
            <div 
              key={index}
              className="group p-8 rounded-[2rem] border border-gray-100 hover:border-brand-200 hover:shadow-xl hover:shadow-pink-50 transition-all duration-300"
            >
              <div className={`w-14 h-14 ${tip.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                {tip.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{tip.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">
                {tip.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-20 bg-brand-600 rounded-[3rem] p-8 md:p-16 text-white relative overflow-hidden">
          <div className="relative z-10 max-w-2xl">
            <h3 className="text-3xl md:text-4xl font-bold mb-6">هل لديكِ أي استفسار طبي؟</h3>
            <p className="text-lg opacity-90 mb-10 leading-relaxed">
              فريقنا من الأطباء المتخصصين جاهز للرد على تساؤلاتكِ وتقديم الدعم اللازم لكِ في أي وقت.
            </p>
            <button 
              onClick={onContactClick}
              className="bg-white text-brand-600 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-brand-50 transition-all active:scale-95"
            >
              تحدثي مع طبيب الآن
            </button>
          </div>
          
          {/* Decorative circles */}
          <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/4 w-64 h-64 bg-brand-400/20 rounded-full blur-2xl" />
        </div>
      </div>
    </section>
  );
}
