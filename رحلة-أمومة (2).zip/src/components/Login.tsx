import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { motion } from 'motion/react';
import { Heart, Stethoscope, Calendar } from 'lucide-react';

export default function Login() {
  const { login } = useAuth();
  const [fileNumber, setFileNumber] = useState('');
  const [dob, setDob] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fileNumber || !dob) return;
    setIsSubmitting(true);
    setError('');
    try {
      await login(fileNumber, dob);
    } catch (err: any) {
      console.error("Detailed Login Error:", err);
      // Try to parse if it's our JSON error format
      try {
        const parsed = JSON.parse(err.message);
        setError(parsed.error || 'خطأ في جلب البيانات من المستشفى');
      } catch {
        setError(err.message || 'حدث خطأ أثناء تسجيل الدخول');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuickLogin = async () => {
    setIsSubmitting(true);
    setError('');
    try {
      await login('00000001', '1992-05-12');
    } catch (err: any) {
      setError(err.message || 'خطأ في الدخول السريع');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#fffafb] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-[2.5rem] shadow-2xl shadow-pink-100/50 p-8 md:p-12 border border-pink-50"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-brand-500 rounded-full flex items-center justify-center text-white mx-auto mb-4 shadow-lg shadow-brand-100">
            <Heart size={32} fill="currentColor" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">تسجيل الدخول الطبي</h1>
          <p className="text-gray-500">أدخلي بيانات المستشفى للوصول إلى ملفكِ</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2 mr-2">رقم الملف الطبي</label>
            <div className="relative">
              <Stethoscope className="absolute right-4 top-1/2 -translate-y-1/2 text-brand-300" size={20} />
              <input 
                type="text" 
                value={fileNumber}
                onChange={(e) => setFileNumber(e.target.value)}
                placeholder="مثلاً: 12345"
                className="w-full bg-gray-50 border-none rounded-2xl py-4 pr-12 pl-4 focus:ring-2 focus:ring-brand-500 transition-all outline-none text-right"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2 mr-2">تاريخ الميلاد</label>
            <div className="relative">
              <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 text-brand-300" size={20} />
              <input 
                type="date" 
                value={dob}
                onChange={(e) => setDob(e.target.value)}
                className="w-full bg-gray-50 border-none rounded-2xl py-4 pr-12 pl-4 focus:ring-2 focus:ring-brand-500 transition-all outline-none text-right"
                required
              />
            </div>
          </div>

          {error && (
            <motion.p 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              className="text-red-500 text-sm text-center font-bold"
            >
              {error}
            </motion.p>
          )}

          <button 
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-brand-500 text-white py-4 rounded-2xl font-bold text-lg hover:bg-brand-600 transition-all shadow-xl shadow-brand-200 disabled:opacity-70 active:scale-[0.98]"
          >
            {isSubmitting ? 'جاري التحقق...' : 'دخول'}
          </button>

          <div className="pt-4 space-y-4">
            <button
              onClick={handleQuickLogin}
              disabled={isSubmitting}
              type="button"
              className="w-full bg-brand-50 text-brand-600 py-3 rounded-2xl font-bold text-sm hover:bg-brand-100 transition-all border border-brand-100/50 disabled:opacity-50"
            >
              {isSubmitting ? 'جاري الدخول...' : 'دخول سريع (حساب تجريبي)'}
            </button>
            <div className="text-center">
              <p className="text-[10px] text-brand-400 font-medium opacity-60">
                رقم الملف: 00000001 | الميلاد: 1992-05-12
              </p>
            </div>
          </div>
        </form>

        <div className="mt-8 text-center text-xs text-gray-400">
          <p>يتم استرداد بياناتكِ بشكل آمن من قاعدة بيانات المستشفى</p>
        </div>
      </motion.div>
    </div>
  );
}
