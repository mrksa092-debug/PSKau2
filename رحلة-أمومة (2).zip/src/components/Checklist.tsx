import React, { useState, useEffect } from 'react';
import { CheckCircle2, Circle, Plus, Trash2, Dumbbell, Calendar, Heart, Sparkles, PlayCircle, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { doc, getDoc, setDoc, collection, onSnapshot } from 'firebase/firestore';
import { db } from '../services/firebase';

const getMonthlyGuidance = (week: number) => {
  const month = Math.ceil(week / 4) || 1;
  const common = [
    { id: 'c1', text: "شرب 8 أكواب ماء يومياً", category: 'food' },
    { id: 'c2', text: "المشي لمدة 15-20 دقيقة", category: 'sports', aiGuide: { title: 'المشي الآمن', steps: ['ارتدي حذاءً مريحاً', 'امشي بخطوات منتظمة', 'حافظي على استقامة الظهر'], focus: 'القلب والدورة الدموية' } },
    { id: 'c3', text: "تناول وجبة غنية بالبروتين", category: 'food' },
    { id: 'c4', text: "تمارين التمدد الصباحية", category: 'sports', aiGuide: { title: 'التمدد اللطيف', steps: ['مدي الذراعين للأعلى', 'ميل ببطء للجانبين'], focus: 'مرونة الجسم' } },
  ];

  if (month <= 3) { // First Trimester
    return [
      ...common,
      { id: 't1', text: "تمارين التنفس العميق للاسترخاء", category: 'sports', aiGuide: { title: 'التنفّس العميق', steps: ['اجلسي بوضعية مريحة', 'استنشقي من الأنف لـ 4 ثوانٍ', 'ازفري ببطء من الفم'], focus: 'تقليل التوتر والغثيان' } },
      { id: 't2', text: "تناول مكملات حمض الفوليك", category: 'medical' },
      { id: 't3', text: "وجبة خفيفة قبل النوم لمنع الغثيان", category: 'food' },
      { id: 't4', text: "أخذ قسط كافٍ من الراحة", category: 'personal' },
    ];
  } else if (month <= 6) { // Second Trimester
    return [
      ...common,
      { id: 't1', text: "تمارين كيجل يومياً", category: 'sports', aiGuide: { title: 'تمارين كيجل', steps: ['قبض عضلات الحوض', 'الثبات لـ 3 ثوانٍ', 'الاسترخاء التام'], focus: 'تقوية عضلات الحوض' } },
      { id: 't2', text: "تناول حصة من الفواكه الطازجة", category: 'food' },
      { id: 't3', text: "استخدام مرطب للبطن", category: 'personal' },
      { id: 't4', text: "الاستلقاء على الجانب الأيسر", category: 'personal' },
      { id: 't5', text: "شرب كوب من الحليب أو بدائله", category: 'food' },
    ];
  } else { // Third Trimester
    return [
      ...common,
      { id: 't1', text: "تمارين الكرة الرياضية (الحوض)", category: 'sports', aiGuide: { title: 'كرة الولادة', steps: ['الجلوس بتوازن على الكرة', 'تحريك الحوض بشكل دائري'], focus: 'تسهيل وضعية الجنين' } },
      { id: 't2', text: "تناول 3 حبات تمر (للنشاط)", category: 'food' },
      { id: 't3', text: "تجهيز حقيبة الولادة", category: 'setup' },
      { id: 't4', text: "تمارين القرفصاء الخفيفة", category: 'sports', aiGuide: { title: 'القرفصاء بمسند', steps: ['الاستناد على كرسي', 'النزول ببطء مع استقامة الظهر'], focus: 'فتح الحوض' } },
      { id: 't5', text: "تقليل الملح لتجنب الانتفاخ", category: 'food' },
    ];
  }
};

export default function Checklist() {
  const { patient, user } = useAuth();
  const [tasks, setTasks] = useState<{ id: string | number, text: string, completed: boolean, isCustom?: boolean, category?: string, aiGuide?: any }[]>([]);
  const [newTaskText, setNewTaskText] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [activeGuide, setActiveGuide] = useState<any | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [simStep, setSimStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setSimStep(prev => (prev + 1) % 4);
      }, 2000);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  useEffect(() => {
    if (!patient?.fileNumber) return;

    // Load tasks from Firestore
    const tasksRef = doc(db, 'patients', patient.fileNumber, 'userdata', 'checklist');
    const unsubscribe = onSnapshot(tasksRef, (snap) => {
      if (snap.exists()) {
        setTasks(snap.data().tasks || []);
        setIsInitialLoad(false);
      } else {
        // If no tasks in DB, load default monthly guidance and save it
        if (patient.pregnancyStartDate) {
          const lmp = new Date(patient.pregnancyStartDate);
          const today = new Date();
          const diffDays = Math.floor((today.getTime() - lmp.getTime()) / (1000 * 60 * 60 * 24));
          const currentWeeks = Math.floor(diffDays / 7);
          const guidance = getMonthlyGuidance(currentWeeks);
          const initialTasks = guidance.map(g => ({ ...g, completed: false }));
          setTasks(initialTasks);
          // Save to DB
          setDoc(tasksRef, { tasks: initialTasks }, { merge: true });
        }
        setIsInitialLoad(false);
      }
    });

    return () => unsubscribe();
  }, [patient?.fileNumber, patient?.pregnancyStartDate]);

  const saveTasksToDB = async (updatedTasks: typeof tasks) => {
    if (!patient?.fileNumber) return;
    try {
      const tasksRef = doc(db, 'patients', patient.fileNumber, 'userdata', 'checklist');
      await setDoc(tasksRef, { tasks: updatedTasks }, { merge: true });
    } catch (err) {
      console.error("Error saving tasks:", err);
    }
  };

  const toggleTask = (id: string | number) => {
    const updatedTasks = tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
    setTasks(updatedTasks);
    saveTasksToDB(updatedTasks);
  };

  const openGuide = (guide: any) => {
    setIsGenerating(true);
    setActiveGuide(guide);
    setTimeout(() => setIsGenerating(false), 1500);
  };

  const addTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;
    
    const newTask = {
      id: Date.now(),
      text: newTaskText,
      completed: false,
      isCustom: true,
      category: 'personal'
    };
    
    const updatedTasks = [newTask, ...tasks];
    setTasks(updatedTasks);
    await saveTasksToDB(updatedTasks);
    setNewTaskText('');
    setIsAdding(false);
  };

  const deleteTask = async (id: string | number) => {
    const updatedTasks = tasks.filter(t => t.id !== id);
    setTasks(updatedTasks);
    await saveTasksToDB(updatedTasks);
  };

  const getIcon = (category?: string) => {
    switch (category) {
      case 'sports': return <Dumbbell size={16} className="text-orange-400" />;
      case 'food': return <Heart size={16} className="text-green-400" />;
      case 'medical': return <Heart size={16} className="text-red-400" />;
      case 'personal': return <Sparkles size={16} className="text-blue-400" />;
      case 'setup': return <Calendar size={16} className="text-purple-400" />;
      default: return <Sparkles size={16} className="text-brand-400" />;
    }
  };

  return (
    <section className="py-24 bg-brand-50/10">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto bg-white rounded-[3rem] p-8 md:p-12 shadow-xl shadow-pink-100/30 border border-pink-50">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">قائمتكِ اليومية الذكية</h2>
              <p className="text-gray-500 text-sm">مهام وتدريبات مخصصة لمرحلة حملكِ الحالية</p>
            </div>
            <button 
              onClick={() => setIsAdding(!isAdding)}
              className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg transition-all ${isAdding ? 'bg-gray-400 shadow-gray-100 rotate-45' : 'bg-brand-500 shadow-brand-100 hover:scale-105 active:scale-95'}`}
            >
              <Plus size={24} />
            </button>
          </div>

          <AnimatePresence>
            {isAdding && (
              <motion.form 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                onSubmit={addTask}
                className="mb-8 flex gap-2"
              >
                <input 
                  type="text" 
                  value={newTaskText}
                  onChange={(e) => setNewTaskText(e.target.value)}
                  placeholder="أضيفي مهمة جديدة..."
                  autoFocus
                  className="flex-1 bg-gray-50 border-none rounded-2xl px-5 py-4 focus:ring-2 focus:ring-brand-500 transition-all outline-none text-right"
                />
                <button 
                  type="submit"
                  className="bg-brand-500 text-white px-8 rounded-2xl font-bold hover:bg-brand-600 transition-all"
                >
                  إضافة
                </button>
              </motion.form>
            )}
          </AnimatePresence>

          <div className="space-y-3">
            {tasks.map((task) => (
              <motion.div 
                key={task.id}
                layout
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className={`group flex items-center gap-4 p-4 rounded-2xl transition-all border ${
                  task.completed 
                    ? 'bg-gray-50 opacity-60 border-transparent' 
                    : 'bg-white border-gray-100 hover:border-brand-200 shadow-sm hover:shadow-md'
                }`}
              >
                <button 
                  onClick={() => toggleTask(task.id)}
                  className="shrink-0"
                >
                  {task.completed ? (
                    <CheckCircle2 className="text-brand-500" size={26} />
                  ) : (
                    <Circle className="text-gray-300 hover:text-brand-300" size={26} />
                  )}
                </button>
                
                <div 
                  onClick={() => toggleTask(task.id)}
                  className="flex-1 cursor-pointer"
                >
                  <div className="flex items-center gap-2 mb-0.5">
                    {getIcon(task.category)}
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none">
                      {task.category === 'sports' ? 'تمارين رياضية' : 
                       task.category === 'food' ? 'غذاء صحي' : 
                       task.category === 'medical' ? 'متابعة طبية' : 
                       task.category === 'personal' ? 'عناية شخصية' : 
                       task.category === 'setup' ? 'تجهيزات' : 'عام'}
                    </span>
                  </div>
                  <span className={`text-base font-bold sm:text-lg ${task.completed ? 'line-through text-gray-400' : 'text-gray-800'}`}>
                    {task.text}
                  </span>
                </div>

                {task.aiGuide && !task.completed && (
                  <button 
                    onClick={() => openGuide(task.aiGuide)}
                    className="flex items-center gap-1.5 bg-brand-50 text-brand-600 px-3 py-1.5 rounded-xl hover:bg-brand-100 transition-all group/btn"
                  >
                    <Sparkles size={16} className="group-hover/btn:scale-110 transition-transform" />
                    <span className="text-[10px] font-bold">دليل الذكاء الاصطناعي</span>
                  </button>
                )}

                {task.isCustom && (
                  <button 
                    onClick={() => deleteTask(task.id)}
                    className="opacity-0 group-hover:opacity-100 p-2 text-red-300 hover:text-red-500 transition-all"
                  >
                    <Trash2 size={18} />
                  </button>
                )}
              </motion.div>
            ))}
          </div>

          {tasks.length > 0 && (
            <div className="mt-10 p-6 bg-brand-50 rounded-3xl border border-brand-100/50 flex items-center justify-between">
              <div className="text-sm font-bold text-brand-700">
                أنجزتِ {tasks.filter(t => t.completed).length} من أصل {tasks.length} مهام
              </div>
              <div className="w-32 h-2.5 bg-white rounded-full overflow-hidden shadow-inner">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${(tasks.filter(t => t.completed).length / tasks.length) * 100}%` }}
                  className="h-full bg-brand-500 shadow-sm" 
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* AI Guide Modal */}
      <AnimatePresence>
        {activeGuide && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/40 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-xl bg-white rounded-[3rem] overflow-hidden shadow-2xl border border-pink-50"
            >
              <button 
                onClick={() => setActiveGuide(null)}
                className="absolute top-6 left-6 w-10 h-10 bg-gray-50 hover:bg-gray-100 text-gray-400 rounded-full flex items-center justify-center z-10 transition-all"
              >
                <X size={20} />
              </button>

              <div className="p-8 md:p-12">
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-12 h-12 bg-brand-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-brand-100">
                    <Sparkles size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">{activeGuide.title}</h3>
                    <p className="text-xs text-brand-600 font-bold">تم إنشاؤه بواسطة الذكاء الاصطناعي</p>
                  </div>
                </div>

                {isGenerating ? (
                  <div className="py-12 flex flex-col items-center justify-center space-y-4">
                    <motion.div 
                      animate={{ 
                        scale: [1, 1.2, 1],
                        rotate: [0, 180, 360]
                      }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="w-16 h-16 border-4 border-brand-100 border-t-brand-500 rounded-full"
                    />
                    <div className="text-center">
                      <p className="text-gray-900 font-bold mb-1">جاري معالجة البيانات...</p>
                      <p className="text-gray-400 text-sm animate-pulse">يتم إنشاء الرسومات الكرتونية المحتشمة لكِ</p>
                    </div>
                  </div>
                ) : (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-8"
                  >
                    {/* Interactive Simulator Frame */}
                    <div className="aspect-video bg-brand-50 rounded-3xl border-2 border-brand-100 flex flex-col items-center justify-center p-6 text-center space-y-4 shadow-inner overflow-hidden relative group">
                      <div className="absolute inset-0 bg-gradient-to-tr from-brand-100/10 to-transparent pointer-events-none" />
                      
                      <AnimatePresence mode="wait">
                        <motion.div 
                          key={isPlaying ? simStep : 'paused'}
                          initial={{ scale: 0.8, opacity: 0, y: 10 }}
                          animate={{ scale: 1, opacity: 1, y: 0 }}
                          exit={{ scale: 1.1, opacity: 0, y: -10 }}
                          className="flex flex-col items-center gap-4 z-10"
                        >
                          <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-md relative overflow-hidden">
                            <div className="absolute inset-0 bg-brand-50 opacity-20 animate-pulse" />
                            {activeGuide.title === 'كرة الولادة' ? (
                              <Dumbbell className={`text-brand-500 transition-transform duration-1000 ${isPlaying ? 'scale-125 rotate-12' : ''}`} size={48} />
                            ) : (
                              <motion.div
                                animate={isPlaying ? { scale: [1, 1.1, 1] } : {}}
                                transition={{ repeat: Infinity, duration: 1 }}
                              >
                                <Heart className="text-brand-500" size={48} />
                              </motion.div>
                            )}
                          </div>
                          
                          <div className="space-y-1">
                            <p className="text-sm font-black text-brand-900">
                              {isPlaying 
                                ? `المرحلة ${simStep + 1}: ${activeGuide.steps[simStep] || 'التركيز على التنفس'}`
                                : 'نظام محاكاة التمارين الآمنة'
                              }
                            </p>
                            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">
                              {isPlaying ? 'جاري التشغيل الآن' : 'اضغطي لبدء المحاكاة الكرتونية'}
                            </p>
                          </div>
                        </motion.div>
                      </AnimatePresence>

                      <button 
                        onClick={() => setIsPlaying(!isPlaying)}
                        className="absolute bottom-6 right-6 w-12 h-12 bg-white shadow-lg rounded-2xl flex items-center justify-center text-brand-600 hover:scale-110 active:scale-95 transition-all z-20"
                      >
                        {isPlaying ? <X size={20} /> : <PlayCircle size={24} />}
                      </button>

                      {isPlaying && (
                        <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-brand-100 overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: '100%' }}
                            transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
                            className="h-full bg-brand-500"
                          />
                        </div>
                      )}
                    </div>

                    <div className="grid gap-4">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="w-1.5 h-1.5 bg-brand-500 rounded-full" />
                        <h4 className="font-bold text-gray-800">خطوات التنفيذ:</h4>
                      </div>
                      <div className="space-y-2">
                        {activeGuide.steps.map((step: string, idx: number) => (
                          <motion.div 
                            key={idx}
                            initial={{ x: 20, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            className={`flex items-center gap-3 p-4 rounded-2xl border transition-all ${
                              isPlaying && simStep === idx 
                                ? 'bg-brand-50 border-brand-200 shadow-sm' 
                                : 'bg-gray-50 border-transparent'
                            }`}
                          >
                            <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold shadow-sm shrink-0 ${
                              isPlaying && simStep === idx ? 'bg-brand-500 text-white' : 'bg-white text-brand-600'
                            }`}>
                              {idx + 1}
                            </span>
                            <p className={`text-sm font-bold ${isPlaying && simStep === idx ? 'text-brand-900' : 'text-gray-600'}`}>{step}</p>
                          </motion.div>
                        ))}
                      </div>
                    </div>

                    <div className="p-5 bg-pink-50 rounded-2xl border border-pink-100">
                      <div className="flex items-center gap-2 mb-1">
                        <Heart size={14} className="text-brand-500" />
                        <span className="text-xs font-bold text-brand-700">تركيز التمرين:</span>
                      </div>
                      <p className="text-xs text-brand-600 font-medium leading-relaxed">{activeGuide.focus}</p>
                    </div>

                    <button 
                      onClick={() => setActiveGuide(null)}
                      className="w-full py-4 bg-brand-500 text-white rounded-2xl font-bold shadow-lg shadow-brand-100 hover:bg-brand-600 transition-all flex items-center justify-center gap-2"
                    >
                      فهمت، سأبدأ الآن
                    </button>
                  </motion.div>
                ) }
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
