import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { FileText, Activity, Beaker, CheckCircle, AlertCircle, X, Download, MessageCircle, Calendar } from 'lucide-react';

export default function MedicalProfile({ onDiscuss }: { onDiscuss?: (context: string) => void }) {
  const { patient } = useAuth();
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const [activeReminders, setActiveReminders] = useState<string[]>([]);

  if (!patient) return null;

  const toggleReminder = (id: string) => {
    setActiveReminders(prev => [...prev, id]);
    setTimeout(() => {
      setActiveReminders(prev => prev.filter(rid => rid !== id));
    }, 3000);
  };

  return (
    <div className="space-y-8">
      {/* Appointments Timeline Section */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center text-orange-600">
              <Calendar size={20} />
            </div>
            <h2 className="text-xl font-bold text-gray-900">سجل المواعيد والمتابعة</h2>
          </div>
          <div className="px-4 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full">حالة الحمل: مستقرة</div>
        </div>

        <div className="space-y-6 relative before:absolute before:right-[23px] before:top-4 before:bottom-4 before:w-0.5 before:bg-gray-100">
          {/* Unified Timeline from Patient Reports */}
          {[...(patient.medicalReports || [])]
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .map((report) => {
              const isUpcoming = new Date(report.date).getTime() > Date.now();
              
              if (isUpcoming) {
                return (
                  <motion.div 
                    key={report.id}
                    whileHover={{ x: -10 }}
                    className="relative pr-12"
                  >
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-blue-50 border-4 border-white flex items-center justify-center text-blue-500 shadow-sm z-10">
                      <Calendar size={18} />
                    </div>
                    <div className="bg-blue-50/50 p-6 rounded-[2rem] border border-blue-100 shadow-sm">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-bold text-blue-900">{report.title}</h4>
                        <span className="text-xs bg-blue-500 text-white px-3 py-1 rounded-full font-bold">قادم</span>
                      </div>
                      <p className="text-sm text-blue-700">التاريخ: {new Date(report.date).toLocaleDateString('ar-EG')} • {report.doctor}</p>
                      
                      <AnimatePresence>
                        {activeReminders.includes(report.id) && (
                          <motion.div 
                            initial={{ opacity: 0, y: -10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            className="mt-3 p-3 bg-green-500 text-white text-xs font-bold rounded-xl flex items-center gap-2"
                          >
                            <CheckCircle size={14} />
                            تم تفعيل التذكير! سيتم إعلامكِ قبل موعد المراجعة.
                          </motion.div>
                        )}
                      </AnimatePresence>

                      <div className="mt-4 flex gap-3">
                        <button 
                          onClick={() => toggleReminder(report.id)}
                          className={`text-xs px-4 py-2 rounded-xl font-bold transition-all shadow-sm ${activeReminders.includes(report.id) ? 'bg-green-600 text-white' : 'bg-white text-blue-600 hover:bg-blue-600 hover:text-white'}`}
                        >
                          {activeReminders.includes(report.id) ? 'تم التفعيل' : 'تذكيري'}
                        </button>
                        <button 
                          onClick={() => onDiscuss && onDiscuss(`أرغب في تغيير موعد ${report.title} القادم إلى وقت آخر يناسبني، هل يمكننا التنسيق لتحديد موعد بديل؟`)}
                          className="text-xs bg-white text-blue-600 px-4 py-2 rounded-xl font-bold hover:bg-blue-600 hover:text-white transition-all shadow-sm"
                        >
                          تغيير الموعد
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              }

              return (
                <motion.div 
                  key={report.id}
                  whileHover={{ x: -10 }}
                  onClick={() => setSelectedReport(report)}
                  className="relative pr-12 cursor-pointer group"
                >
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-green-50 border-4 border-white flex items-center justify-center text-green-500 shadow-sm z-10 group-hover:bg-green-500 group-hover:text-white transition-all">
                    <CheckCircle size={18} />
                  </div>
                  <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm hover:border-brand-200 transition-all">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-bold text-gray-900">{report.title}</h4>
                      <span className="text-xs bg-green-100 text-green-600 px-3 py-1 rounded-full font-bold">تم الحضور</span>
                    </div>
                    <p className="text-xs text-gray-400 mb-4">{new Date(report.date).toLocaleDateString('ar-EG')} • {report.doctor}</p>
                    <div className="p-4 bg-gray-50 rounded-2xl text-sm text-gray-600 line-clamp-2">
                      {report.summary}
                    </div>
                    <div className="mt-4 text-xs font-bold text-brand-500 group-hover:underline">عرض ملخص الموعد بالكامل ←</div>
                  </div>
                </motion.div>
              );
            })}
        </div>
      </section>

      {/* Medications Section */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-pink-100 flex items-center justify-center text-pink-600">
            <Beaker size={20} />
          </div>
          <h2 className="text-xl font-bold text-gray-900">الأدوية الموصوفة</h2>
        </div>

        <div className="space-y-4">
          {patient.medications?.map((med) => (
            <motion.div 
              key={med.id}
              className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-brand-50 flex items-center justify-center text-brand-500">
                    <CheckCircle size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg text-gray-900">{med.name}</h4>
                    <p className="text-sm text-brand-600 font-bold">{med.dosage} • {med.frequency}</p>
                  </div>
                </div>
                <button 
                  onClick={() => onDiscuss && onDiscuss(`بخصوص دواء ${med.name}: استفسار عن الأعراض الجانبية`)}
                  className="bg-brand-50 text-brand-500 px-4 py-2 rounded-xl text-xs font-black hover:bg-brand-500 hover:text-white transition-all"
                >
                  ناقش الأعراض مع الطبيب
                </button>
              </div>
              
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4 text-right" dir="rtl">
                <div className="p-4 bg-gray-50 rounded-2xl">
                  <p className="text-[10px] text-gray-400 font-bold uppercase mb-2">تعليمات الاستخدام</p>
                  <p className="text-sm text-gray-700 leading-relaxed">{med.instructions}</p>
                </div>
                <div className="p-4 bg-orange-50/50 rounded-2xl">
                  <p className="text-[10px] text-orange-400 font-bold uppercase mb-2">الأعراض الجانبية المحتملة</p>
                  <p className="text-sm text-gray-700 leading-relaxed">{med.sideEffects}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Lab Results Section */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center text-blue-600">
            <Beaker size={20} />
          </div>
          <h2 className="text-xl font-bold text-gray-900">آخر نتائج المختبر</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {patient.labResults?.map((lab) => (
            <motion.div 
              key={lab.id}
              whileHover={{ scale: 1.02 }}
              className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between"
            >
              <div>
                <p className="text-xs text-gray-400 mb-1">{lab.date}</p>
                <h4 className="font-bold text-gray-800">{lab.testName}</h4>
                <div className="flex items-center gap-2 mt-2">
                  <span className={`text-lg font-black ${lab.status === 'normal' ? 'text-green-600' : 'text-orange-500'}`}>
                    {lab.result} {lab.unit}
                  </span>
                  <span className="text-[10px] text-gray-400 bg-gray-50 px-2 py-0.5 rounded-full">
                    المعدل: {lab.range}
                  </span>
                </div>
              </div>
              <div>
                {lab.status === 'normal' ? (
                  <CheckCircle className="text-green-500" size={24} />
                ) : (
                  <AlertCircle className="text-orange-500" size={24} />
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Medical Reports Section */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center text-purple-600">
            <Activity size={20} />
          </div>
          <h2 className="text-xl font-bold text-gray-900">التقارير الطبية</h2>
        </div>

        <div className="space-y-4">
          {patient.medicalReports?.map((report) => (
            <motion.div 
              key={report.id}
              layoutId={report.id}
              onClick={() => setSelectedReport(report)}
              className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-all cursor-pointer group"
            >
              <div className="flex items-start justify-between">
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-brand-50 flex items-center justify-center text-brand-500 group-hover:bg-brand-500 group-hover:text-white transition-colors">
                    <FileText size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg text-gray-900">{report.title}</h4>
                    <p className="text-sm text-gray-400">{report.doctor} • {new Date(report.date).toLocaleDateString('ar-EG')}</p>
                  </div>
                </div>
                <button className="text-brand-500 font-bold text-sm bg-brand-50 px-4 py-2 rounded-xl hover:bg-brand-500 hover:text-white transition-all">
                  عرض التقرير
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Report Modal */}
      <AnimatePresence>
        {selectedReport && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedReport(null)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              layoutId={selectedReport.id}
              className="bg-white rounded-[2.5rem] w-full max-w-2xl overflow-hidden shadow-2xl relative z-10"
            >
              <div className="p-8 border-b border-gray-100 flex items-center justify-between bg-brand-500 text-white">
                <div>
                  <h3 className="text-2xl font-black">{selectedReport.title}</h3>
                  <p className="text-white/80 text-sm">تم إصداره في {new Date(selectedReport.date).toLocaleDateString('ar-EG')}</p>
                </div>
                <button 
                  onClick={() => setSelectedReport(null)}
                  className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className="p-8 space-y-6">
                <div className="flex items-center gap-6 p-4 bg-gray-50 rounded-2xl">
                  <div className="w-12 h-12 rounded-full bg-white shadow-sm flex items-center justify-center">
                    <Activity className="text-brand-500" size={24} />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">الطبيب المشرف</p>
                    <p className="font-bold text-gray-900">{selectedReport.doctor}</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-lg mb-3 flex items-center gap-2">
                    <CheckCircle className="text-green-500" size={20} />
                    ملخص الفحص
                  </h4>
                  <div className="bg-green-50/50 p-6 rounded-3xl border border-green-100 text-gray-700 leading-relaxed text-lg">
                    {selectedReport.summary}
                  </div>
                </div>

                <div className="flex gap-4">
                  <button className="flex-1 bg-brand-500 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-brand-600 transition-all">
                    <Download size={20} />
                    تحميل التقرير PDF
                  </button>
                  <button 
                    onClick={() => {
                      if (onDiscuss) onDiscuss(`بخصوص التقرير: ${selectedReport.title}`);
                      setSelectedReport(null);
                    }}
                    className="flex-1 border-2 border-gray-100 text-gray-500 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-gray-50 transition-all"
                  >
                    <MessageCircle size={20} />
                    ناقش مع طبيبك
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
