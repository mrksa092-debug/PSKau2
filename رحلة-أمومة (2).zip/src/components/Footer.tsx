import { Heart, Instagram, Twitter, Facebook } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-pink-50 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Heart className="text-brand-500" fill="currentColor" size={24} />
              <span className="text-2xl font-bold text-gray-900">رحلة أمومة</span>
            </div>
            <p className="text-gray-500 max-w-sm leading-relaxed">
              نحن هنا لنرافقكِ في أجمل رحلة في حياتكِ. نقدم لكِ المعلومات الموثوقة والأدوات التي تحتاجينها لضمان صحتكِ وصحة جنينكِ.
            </p>
          </div>
          
          <div>
            <h4 className="font-bold text-gray-900 mb-6">روابط سريعة</h4>
            <ul className="space-y-4 text-gray-500 text-sm">
              <li><a href="#" className="hover:text-brand-500 transition-colors">عن الموقع</a></li>
              <li><a href="#" className="hover:text-brand-500 transition-colors">سياسة الخصوصية</a></li>
              <li><a href="#" className="hover:text-brand-500 transition-colors">الشروط والأحكام</a></li>
              <li><a href="#" className="hover:text-brand-500 transition-colors">اتصلي بنا</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-gray-900 mb-6">تابعينا</h4>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-brand-50 flex items-center justify-center text-brand-500 hover:bg-brand-500 hover:text-white transition-all">
                <Instagram size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-brand-50 flex items-center justify-center text-brand-500 hover:bg-brand-500 hover:text-white transition-all">
                <Twitter size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-brand-50 flex items-center justify-center text-brand-500 hover:bg-brand-500 hover:text-white transition-all">
                <Facebook size={20} />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-100 pt-8 text-center text-gray-400 text-xs">
          <p>© {new Date().getFullYear()} رحلة أمومة. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  );
}
