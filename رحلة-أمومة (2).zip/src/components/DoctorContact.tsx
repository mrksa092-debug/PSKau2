import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { Send, User, Check, SendHorizonal, Phone, Video, Calendar, ShieldCheck, ClipboardList, X } from 'lucide-react';

export default function DoctorContact({ initialContext, onContextClear }: { initialContext?: string | null, onContextClear?: () => void }) {
  const { patient } = useAuth();
  const [msg, setMsg] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [patient?.messages]);

  const handleSend = () => {
    if (!msg.trim()) return;
    // In a real app, this would send to Firebase
    setMsg('');
    if (onContextClear) onContextClear();
  };

  if (!patient) return null;

  return (
    <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden flex flex-col h-[600px]">
      {/* Header */}
      <div className="p-6 border-b border-gray-50 flex items-center justify-between bg-white sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-12 h-12 rounded-2xl bg-brand-50 flex items-center justify-center text-brand-600">
              <User size={24} />
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">د. هند المنصور</h3>
            <p className="text-xs text-brand-500 font-medium">استشارية نساء ولادة • متصلة الآن</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="w-10 h-10 rounded-xl bg-gray-50 text-gray-400 flex items-center justify-center hover:bg-brand-50 hover:text-brand-500 transition-all">
            <Phone size={18} />
          </button>
          <button className="w-10 h-10 rounded-xl bg-gray-50 text-gray-400 flex items-center justify-center hover:bg-brand-50 hover:text-brand-500 transition-all">
            <Video size={18} />
          </button>
        </div>
      </div>

      {/* Security Banner */}
      <div className="bg-blue-50/50 px-6 py-2 flex items-center justify-center gap-2 text-[10px] text-blue-600 font-medium">
        <ShieldCheck size={12} />
        هذه المحادثة مشفرة وبحماية طبية عالية (HIPAA Compliant)
      </div>

      {/* Messages */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-6 bg-gray-50/30"
      >
        <div className="text-center">
          <span className="text-[10px] bg-white border border-gray-100 text-gray-400 px-3 py-1 rounded-full px-2">اليوم</span>
        </div>

        {patient.messages?.map((m) => (
          <motion.div 
            key={m.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${m.sender === 'patient' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`max-w-[80%] p-4 rounded-2xl shadow-sm ${
              m.sender === 'patient' 
                ? 'bg-brand-500 text-white rounded-tr-none' 
                : 'bg-white text-gray-800 rounded-tl-none border border-gray-100'
            }`}>
              <p className="text-sm leading-relaxed">{m.text}</p>
              <p className={`text-[10px] mt-2 flex items-center gap-1 ${m.sender === 'patient' ? 'text-white/70' : 'text-gray-400'}`}>
                {new Date(m.timestamp).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                {m.sender === 'patient' && <Check size={10} />}
              </p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Input */}
      <div className="p-6 bg-white border-t border-gray-50">
        <AnimatePresence>
          {initialContext && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="mb-4 bg-brand-50 p-3 rounded-xl border border-brand-100 flex items-center justify-between"
            >
              <div className="flex items-center gap-2 text-brand-700 text-xs font-bold">
                <ClipboardList size={14} />
                إشارة مرجعية: {initialContext}
              </div>
              <button 
                onClick={onContextClear}
                className="text-brand-400 hover:text-brand-600"
              >
                <X size={14} />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
        <div className="flex gap-4 items-center">
          <button className="w-10 h-10 rounded-xl bg-gray-50 text-gray-400 flex items-center justify-center hover:text-brand-500 transition-all">
            <Calendar size={20} />
          </button>
          <div className="flex-1 relative">
            <input 
              type="text"
              value={msg}
              onChange={(e) => setMsg(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="اكتب استشارتك هنا..."
              className="w-full bg-gray-50 border-none rounded-2xl py-4 px-6 text-sm focus:ring-2 focus:ring-brand-200 transition-all outline-none"
            />
            <button 
              onClick={handleSend}
              className="absolute left-2 top-2 bottom-2 bg-brand-500 text-white w-10 h-10 rounded-xl flex items-center justify-center hover:bg-brand-600 transition-all shadow-lg shadow-brand-200"
            >
              <SendHorizonal size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
