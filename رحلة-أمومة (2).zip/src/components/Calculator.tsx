import { useState, useEffect, useCallback } from 'react';
import { Calendar, Info, CheckCircle2, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';

export default function Calculator() {
  const { patient } = useAuth();
  const [date, setDate] = useState('');
  const [result, setResult] = useState<{ dueDate: string; weeks: number; days: number } | null>(null);

  const calculateFromDate = useCallback((inputDate: string) => {
    const lmp = new Date(inputDate);
    const dueDate = new Date(lmp.getTime() + 280 * 24 * 60 * 60 * 1000);
    
    const today = new Date();
    const diffTime = today.getTime() - lmp.getTime();
    const totalDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(totalDays / 7);
    const days = totalDays % 7;

    setResult({
      dueDate: dueDate.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' }),
      weeks,
      days
    });
  }, []);

  useEffect(() => {
    if (patient?.pregnancyStartDate) {
      calculateFromDate(patient.pregnancyStartDate);
    }
  }, [patient, calculateFromDate]);

  const handleManualCalculate = () => {
    if (date) calculateFromDate(date);
  };

  return (
    <section id="calculator" className="py-24 bg-brand-50/50 rounded-[3rem]">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">حالة حملكِ الحالية</h2>
            <p className="text-gray-500">
              {patient 
                ? `بناءً على ملفكِ الطبي في ${patient.hospitalName}، إليكِ تفاصيل مرحلتكِ الحالية.`
                : 'أدخلي تاريخ أول يوم من آخر دورة شهرية لمعرفة موعد ولادتكِ المتوقع ومرحلة حملكِ الحالية.'
              }
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {!patient && (
              <div className="bg-white p-8 rounded-[2rem] shadow-xl shadow-pink-100/50 border border-pink-50">
                <div className="mb-8">
                  <label className="block text-sm font-bold text-gray-700 mb-3">تاريخ آخر دورة شهرية</label>
                  <div className="relative">
                    <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 text-brand-400" size={20} />
                    <input 
                      type="date" 
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full bg-gray-50 border-none rounded-2xl py-4 pr-12 pl-4 focus:ring-2 focus:ring-brand-500 transition-all outline-none text-right"
                    />
                  </div>
                </div>

                <button 
                  onClick={handleManualCalculate}
                  disabled={!date}
                  className="w-full bg-brand-500 text-white py-4 rounded-2xl font-bold text-lg hover:bg-brand-600 transition-all shadow-lg shadow-brand-100 disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]"
                >
                  احسبي الآن
                </button>
              </div>
            )}

            {patient && (
              <div className="bg-white p-8 rounded-[2rem] shadow-xl shadow-pink-100/50 border border-pink-50 flex flex-col items-center justify-center text-center">
                <div className="w-20 h-20 bg-brand-50 rounded-full flex items-center justify-center text-brand-500 mb-6">
                  <RefreshCw size={32} className="animate-spin-slow" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">تزامن البيانات الطبي</h3>
                <p className="text-sm text-gray-500 leading-relaxed">
                  نحن نقرأ بياناتكِ مباشرة من السجل الطبي لضمان أعلى مستويات الدقة في متابعة مراحل نمو جنينكِ.
                </p>
              </div>
            )}

            <div className="min-h-[300px] flex items-center justify-center">
              <AnimatePresence mode="wait">
                {result ? (
                  <motion.div
                    key="result"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="w-full space-y-6"
                  >
                    <div className="bg-white p-8 rounded-[2rem] shadow-xl shadow-pink-100/50 border border-pink-50 text-center">
                      <p className="text-gray-500 font-bold mb-2">موعد الولادة المتوقع</p>
                      <h3 className="text-3xl md:text-4xl font-black bg-clip-text text-transparent bg-gradient-to-r from-brand-600 to-pink-500 mb-6">{result.dueDate}</h3>
                      
                      <div className="h-px bg-gray-100 mb-6" />
                      
                      <div className="flex justify-around">
                        <div className="text-center">
                          <p className="text-5xl font-black text-brand-600 drop-shadow-sm">{result.weeks}</p>
                          <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">أسبوعاً</p>
                        </div>
                        <div className="text-center">
                          <p className="text-5xl font-black text-gray-900 drop-shadow-sm">{result.days}</p>
                          <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">يوم</p>
                        </div>
                      </div>
                      
                      <div className="mt-8 bg-brand-50 p-4 rounded-2xl border border-brand-100">
                        <p className="text-sm text-brand-700 font-bold">
                          بناءً على بداية حملكِ في {patient ? new Date(patient.pregnancyStartDate).toLocaleDateString('ar-EG') : '...'}، أنتِ الآن تعيشين أجمل لحظات الأسبوع {result.weeks}!
                        </p>
                      </div>
                    </div>

                    <div className="bg-brand-500 p-6 rounded-[2rem] text-white flex items-center gap-4">
                      <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                        <CheckCircle2 size={24} />
                      </div>
                      <div className="text-right">
                        <p className="font-bold">مرحلة رائعة يا {patient?.name.split(' ')[0] || 'أم'}!</p>
                        <p className="text-sm opacity-90">لقد أكملتِ {Math.round((result.weeks / 40) * 100)}% من رحلتكِ المباركة.</p>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="placeholder"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-center text-gray-400"
                  >
                    <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Calendar size={32} />
                    </div>
                    <p className="font-bold">جاري تحميل بياناتكِ الطبية...</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
