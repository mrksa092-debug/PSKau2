import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db, handleFirestoreError } from '../services/firebase';
import { collection, query, getDocs, orderBy, limit } from 'firebase/firestore';
import { motion } from 'motion/react';
import { Calendar, User, FileText, Activity, LogOut, ChevronLeft, Bell, Heart, ClipboardList, MessageCircle, Users } from 'lucide-react';
import Calculator from './Calculator';
import WeeklyProgress from './WeeklyProgress';
import Checklist from './Checklist';
import Tips from './Tips';
import MedicalProfile from './MedicalProfile';
import DoctorContact from './DoctorContact';

export default function Dashboard() {
  const { patient, logout } = useAuth();
  const [appointments, setAppointments] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'journey' | 'medical' | 'doctor'>('journey');
  const [messageContext, setMessageContext] = useState<string | null>(null);
  const [showNotifications, setShowNotifications] = useState(false);

  const notifications = [
    { id: 1, text: 'موعدك القادم: تصوير سونار تفصيلي', time: 'بعد 5 أيام', type: 'appointment', path: 'journey' },
    { id: 2, text: 'نتائج تحليل السكر متوفرة الآن', time: 'منذ يومين', type: 'lab', path: 'medical' },
    { id: 3, text: 'رسالة جديدة من د. هند المنصور', time: 'منذ ساعة', type: 'message', path: 'doctor' },
  ];

  const startDiscussion = (context: string) => {
    setMessageContext(context);
    setActiveTab('doctor');
  };

  useEffect(() => {
    if (!patient) return;

    const fetchAppointments = async () => {
      try {
        const q = query(
          collection(db, 'patients', patient.fileNumber, 'appointments'),
          orderBy('date', 'asc'),
          limit(3)
        );
        const snap = await getDocs(q);
        setAppointments(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (err) {
        console.error("Error fetching appointments:", err);
      }
    };

    fetchAppointments();
  }, [patient]);

  if (!patient) return null;

  return (
    <div className="bg-[#fffafb] min-h-screen">
      {/* Top Navbar */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-pink-50 sticky top-0 z-40">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={logout}
              className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 hover:bg-brand-50 hover:text-brand-500 transition-all"
            >
              <LogOut size={20} />
            </button>
            <div className="w-10 h-10 rounded-full bg-brand-500 flex items-center justify-center text-white">
              <User size={20} />
            </div>
            <div className="text-right">
              <div className="flex items-center gap-2">
                <h4 className="font-bold text-gray-900 text-sm">{patient.name}</h4>
                {patient.fileNumber === '00000001' && (
                  <span className="px-2 py-0.5 bg-brand-100 text-brand-700 text-[10px] font-bold rounded-full animate-pulse">
                    وضع المحاكاة
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-400">رقم الملف: {patient.fileNumber}</p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-2 bg-gray-50 p-1 rounded-2xl">
            <button 
              onClick={() => setActiveTab('journey')}
              className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'journey' ? 'bg-white text-brand-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
            >
              رحلتي
            </button>
            <button 
              onClick={() => setActiveTab('medical')}
              className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'medical' ? 'bg-white text-brand-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
            >
              الملف الطبي
            </button>
            <button 
              onClick={() => setActiveTab('doctor')}
              className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'doctor' ? 'bg-white text-brand-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
            >
              تواصل مع الطبيب
            </button>
          </div>

          <div className="flex items-center gap-4">
            <h1 
              onClick={() => setActiveTab('journey')}
              className="text-xl font-bold text-brand-600 hidden lg:block cursor-pointer hover:opacity-80 transition-all select-none"
            >
              رحلة أمومة
            </h1>
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all relative ${showNotifications ? 'bg-brand-500 text-white' : 'bg-gray-50 text-gray-400 hover:bg-brand-50 hover:text-brand-500'}`}
              >
                <Bell size={20} />
                {!showNotifications && <span className="absolute top-2 right-2 w-2 h-2 bg-brand-500 rounded-full" />}
              </button>

              {showNotifications && (
                <div className="absolute top-full left-0 mt-3 w-80 bg-white rounded-3xl shadow-2xl border border-pink-50 p-4 z-50 animate-in fade-in slide-in-from-top-2">
                  <div className="flex items-center justify-between mb-4 px-2">
                    <h5 className="font-bold text-gray-900">التنبيهات</h5>
                    <button onClick={() => setShowNotifications(false)} className="text-[10px] text-brand-600 font-bold hover:underline">إخفاء الكل</button>
                  </div>
                  <div className="space-y-2">
                    {notifications.map((n) => (
                      <div 
                        key={n.id} 
                        onClick={() => {
                          setActiveTab(n.path as any);
                          setShowNotifications(false);
                        }}
                        className="p-3 bg-gray-50 hover:bg-brand-50 rounded-2xl transition-all cursor-pointer border border-transparent hover:border-brand-100 flex gap-3"
                      >
                        <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-brand-500 shadow-sm">
                          {n.type === 'appointment' ? <Calendar size={14} /> : n.type === 'lab' ? <FileText size={14} /> : <MessageCircle size={14} />}
                        </div>
                        <div className="flex-1">
                          <p className="text-xs font-bold text-gray-800">{n.text}</p>
                          <p className="text-[10px] text-gray-400 mt-1">{n.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Mobile Tabs */}
        <div className="md:hidden flex overflow-x-auto border-t border-gray-50 no-scrollbar">
          <button 
            onClick={() => setActiveTab('journey')}
            className={`flex-1 min-w-[100px] py-4 text-xs font-bold border-b-2 transition-all flex flex-col items-center gap-1 ${activeTab === 'journey' ? 'border-brand-500 text-brand-600 bg-brand-50/20' : 'border-transparent text-gray-400'}`}
          >
            <Heart size={16} />
            رحلتي
          </button>
          <button 
            onClick={() => setActiveTab('medical')}
            className={`flex-1 min-w-[100px] py-4 text-xs font-bold border-b-2 transition-all flex flex-col items-center gap-1 ${activeTab === 'medical' ? 'border-brand-500 text-brand-600 bg-brand-50/20' : 'border-transparent text-gray-400'}`}
          >
            <ClipboardList size={16} />
            الملف الطبي
          </button>
          <button 
            onClick={() => setActiveTab('doctor')}
            className={`flex-1 min-w-[100px] py-4 text-xs font-bold border-b-2 transition-all flex flex-col items-center gap-1 ${activeTab === 'doctor' ? 'border-brand-500 text-brand-600 bg-brand-50/20' : 'border-transparent text-gray-400'}`}
          >
            <MessageCircle size={16} />
            الطبيب
          </button>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column (Shared) */}
          <div className="lg:col-span-1 space-y-8">
            {/* Health Passport Card */}
            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-white rounded-[2.5rem] p-8 shadow-xl shadow-pink-100/30 border border-pink-50 overflow-hidden relative"
            >
              <div className="absolute -top-10 -left-10 w-32 h-32 bg-brand-50 rounded-full blur-3xl opacity-50" />
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-blue-50 rounded-full blur-3xl opacity-50" />
              
              <div className="flex items-center justify-between mb-8 relative z-10">
                <div>
                  <h3 className="font-bold text-xl text-gray-900 leading-tight">بطاقتكِ الصحية</h3>
                  <p className="text-xs text-gray-400 mt-1">المعلومات الأساسية والطبية</p>
                </div>
                <div className="w-12 h-12 rounded-2xl bg-brand-500 flex items-center justify-center text-white shadow-lg shadow-brand-200">
                  <Activity size={24} />
                </div>
              </div>

              <div className="space-y-4 relative z-10">
                {/* Personal Info */}
                <div className="bg-gray-50/80 backdrop-blur-sm p-4 rounded-3xl border border-white space-y-3">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-400 font-medium">الاسم الكامل</span>
                    <span className="font-bold text-gray-900">{patient.name}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-400 font-medium">العمر</span>
                    <span className="font-black text-brand-600 bg-brand-50 px-3 py-1 rounded-full">{patient.age} عاماً</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-400 font-medium">فصيلة الدم</span>
                    <span className="px-3 py-1 bg-brand-500 text-white rounded-xl font-black text-xs shadow-sm">{patient.bloodType}</span>
                  </div>
                </div>

                {/* Pregnancy Details */}
                <div className="grid grid-cols-1 gap-3">
                  <div className="bg-blue-50/50 p-5 rounded-3xl border border-blue-100 flex items-center justify-between group hover:bg-blue-50 transition-all">
                    <div>
                      <p className="text-[10px] text-blue-400 font-bold uppercase mb-1 tracking-widest">بداية وعمر الحمل الحالي</p>
                      <p className="text-sm font-black text-blue-900 group-hover:text-blue-600 transition-colors">
                        {new Date(patient.pregnancyStartDate).toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' })} 
                        <span className="mx-2 text-blue-200">/</span>
                        {(() => {
                          const weeks = Math.floor((Date.now() - new Date(patient.pregnancyStartDate).getTime()) / (1000 * 60 * 60 * 24 * 7));
                          const stage = weeks <= 13 ? 'المرحلة الأولى' : weeks <= 26 ? 'المرحلة الثانية' : 'المرحلة الثالثة';
                          return `الأسبوع ${weeks} (${stage})`;
                        })()}
                      </p>
                    </div>
                    <Activity size={20} className="text-blue-300" />
                  </div>
                  <div className="bg-orange-50/50 p-5 rounded-3xl border border-orange-100 flex items-center justify-between group hover:bg-orange-50 transition-all">
                    <div>
                      <p className="text-[10px] text-orange-400 font-bold uppercase mb-1 tracking-widest">موعد الولادة المتوقع</p>
                      <p className="text-lg font-black text-orange-900 group-hover:text-orange-600 transition-colors">
                        {new Date(patient.expectedDeliveryDate).toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' })}
                      </p>
                    </div>
                    <Calendar size={20} className="text-orange-300" />
                  </div>
                </div>

                {/* Clinical History */}
                <div className="bg-purple-50/30 p-5 rounded-3xl border border-purple-100 space-y-4">
                  <div className="flex items-center gap-2 mb-2">
                    <ClipboardList size={16} className="text-purple-500" />
                    <h4 className="text-xs font-black text-purple-700 uppercase tracking-wider">التاريخ السريري الكامل</h4>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-white p-3 rounded-2xl border border-purple-50">
                        <p className="text-[9px] text-purple-400 font-bold mb-1">عدد الأحمال</p>
                        <p className="text-sm font-bold text-purple-900">{patient.gravida} مرات</p>
                      </div>
                      <div className="bg-white p-3 rounded-2xl border border-purple-50">
                        <p className="text-[9px] text-purple-400 font-bold mb-1">عدد الولادات</p>
                        <p className="text-sm font-bold text-purple-900">{patient.parity} مرات</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-[10px] text-purple-400 font-bold mb-1">الأمراض العائلية / السابقة</p>
                      <div className="flex flex-wrap gap-1">
                        {[...(patient.pastMedicalHistory || []), ...(patient.familyHistory || [])].map((h, i) => (
                          <span key={i} className="text-[10px] bg-white text-purple-600 px-2 py-1 rounded-md border border-purple-100 shadow-sm">
                            {h}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Hospital Info */}
                <div className="flex items-center gap-3 p-4 bg-brand-500 rounded-3xl text-white shadow-lg shadow-brand-100">
                  <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                    <Users size={20} />
                  </div>
                  <div className="flex-1">
                    <p className="text-[10px] text-white/70 font-bold uppercase">المستشفى المتابع</p>
                    <p className="text-xs font-bold leading-tight">{patient.hospitalName}</p>
                  </div>
                </div>
              </div>
              
              {/* Community Engagement */}
              <div className="mt-8 border-t border-gray-100 pt-6">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                    <Heart size={16} />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-gray-900">نصيحة مجتمعية اليوم</h5>
                    <p className="text-[11px] text-gray-500 mt-1 leading-relaxed">
                      اللقاءات الودية مع أمهات في نفس شهركِ يقلل من توتر ما قبل الولادة بنسبة 40%. شاركي تجربتكِ!
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Next Appointment Card (Static here, clickable to change tab) */}
            <div className="bg-white rounded-[2.5rem] p-8 shadow-xl shadow-pink-100/30 border border-pink-50">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-bold text-lg">المواعيد القادمة</h3>
                <Calendar className="text-brand-500" size={24} />
              </div>
              <div className="space-y-4">
                {appointments.length > 0 ? appointments.map((appt) => (
                  <div key={appt.id} className="p-4 rounded-2xl border border-gray-100 hover:border-brand-200 transition-all flex items-center justify-between group">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400 group-hover:bg-brand-50 group-hover:text-brand-500">
                        <FileText size={18} />
                      </div>
                      <div>
                        <p className="font-bold text-sm">{appt.type}</p>
                        <p className="text-xs text-gray-400">{new Date(appt.date).toLocaleDateString('ar-EG')}</p>
                      </div>
                    </div>
                    <ChevronLeft size={16} className="text-gray-300" />
                  </div>
                )) : (
                  <p className="text-sm text-gray-400 text-center py-4">لا توجد مواعيد مجدولة حالياً</p>
                )}
                <button 
                  onClick={() => setActiveTab('medical')}
                  className="w-full py-3 text-xs font-bold text-brand-600 hover:underline"
                >
                  مشاهدة جميع التقارير
                </button>
              </div>
            </div>
          </div>

          {/* Right Column (Dynamic) */}
          <div className="lg:col-span-2 space-y-12">
            <motion.div 
              key={activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              {activeTab === 'journey' && (
                <>
                  <Calculator />
                  <WeeklyProgress />
                  <Checklist />
                  
                  {/* Video Section */}
                  <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-pink-50/50 mb-12 overflow-hidden">
                    <div className="flex items-center justify-between mb-6">
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 mb-1">دليل تمارين الحمل الآمنة</h3>
                        <p className="text-sm text-gray-500">تمارين مخصصة لكل مرحلة لتعزيز صحتك وراحتك</p>
                      </div>
                      <div className="w-12 h-12 bg-brand-50 rounded-2xl flex items-center justify-center text-brand-500">
                        <Activity size={24} />
                      </div>
                    </div>
                    <div className="aspect-video w-full rounded-2xl overflow-hidden shadow-inner bg-gray-100">
                      <iframe
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/koKyrFyscTs"
                        title="Pregnancy Safe Exercises"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowFullScreen
                      ></iframe>
                    </div>
                  </div>

                  <Tips onContactClick={() => setActiveTab('doctor')} />
                </>
              )}
              {activeTab === 'medical' && <MedicalProfile onDiscuss={startDiscussion} />}
              {activeTab === 'doctor' && (
                <DoctorContact 
                  initialContext={messageContext} 
                  onContextClear={() => setMessageContext(null)} 
                />
              )}
            </motion.div>
          </div>

        </div>
      </main>
    </div>
  );
}
