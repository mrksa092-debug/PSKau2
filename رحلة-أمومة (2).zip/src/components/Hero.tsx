import { motion } from 'motion/react';
import { Sparkles } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative overflow-hidden pt-20 pb-32">
      {/* Background elements */}
      <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-[600px] h-[600px] bg-brand-100/30 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/4 w-[400px] h-[400px] bg-pink-100/20 rounded-full blur-3xl -z-10" />

      <div className="container mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-50 text-brand-600 text-sm font-bold mb-8">
            <Sparkles size={16} />
            <span>رفيقكِ الموثوق في رحلة الأمومة</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6 leading-tight">
            نهتم بكِ وبطفلكِ <br />
            <span className="text-brand-500">في كل خطوة</span>
          </h1>
          
          <p className="text-xl text-gray-500 max-w-2xl mx-auto mb-12 leading-relaxed">
            تابعي مراحل نمو جنينكِ أسبوعاً بأسبوع، واحصل على نصائح طبية وغذائية مخصصة لكِ من خبراء متخصصين.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button className="w-full sm:w-auto bg-brand-500 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-brand-600 transition-all shadow-xl shadow-brand-200 active:scale-95">
              ابدئي رحلتكِ الآن
            </button>
            <button className="w-full sm:w-auto bg-white text-gray-700 px-8 py-4 rounded-2xl font-bold text-lg border border-gray-100 hover:bg-gray-50 transition-all active:scale-95">
              تعرفي على المزيد
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mt-20 relative max-w-5xl mx-auto"
        >
          <div className="aspect-video rounded-[2.5rem] overflow-hidden shadow-2xl shadow-pink-200/50 border-8 border-white">
            <img 
              src="https://picsum.photos/seed/pregnancy/1200/800" 
              alt="Pregnancy Journey" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          
          {/* Floating cards for visual interest */}
          <div className="absolute -top-10 -right-10 hidden lg:block glass-card p-6 rounded-3xl soft-shadow animate-bounce-slow">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                🥗
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-400 font-bold">نصيحة اليوم</p>
                <p className="text-sm font-bold">تناولي الفواكه الطازجة</p>
              </div>
            </div>
          </div>

          <div className="absolute -bottom-10 -left-10 hidden lg:block glass-card p-6 rounded-3xl soft-shadow animate-bounce-slow" style={{ animationDelay: '1s' }}>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
                📅
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-400 font-bold">الموعد القادم</p>
                <p className="text-sm font-bold">بعد يومين - فحص دوري</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
