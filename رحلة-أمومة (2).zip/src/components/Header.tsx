import { Heart } from 'lucide-react';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-pink-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-brand-500 rounded-full flex items-center justify-center text-white shadow-lg shadow-brand-200">
            <Heart size={20} fill="currentColor" />
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-brand-600 to-brand-400 bg-clip-text text-transparent">
            رحلة أمومة
          </span>
        </div>
        
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-600">
          <a href="#" className="hover:text-brand-500 transition-colors">الرئيسية</a>
          <a href="#calculator" className="hover:text-brand-500 transition-colors">حاسبة الحمل</a>
          <a href="#progress" className="hover:text-brand-500 transition-colors">تطور الجنين</a>
          <a href="#tips" className="hover:text-brand-500 transition-colors">نصائح</a>
        </nav>

        <button className="bg-brand-500 text-white px-5 py-2 rounded-full text-sm font-bold hover:bg-brand-600 transition-all shadow-md shadow-brand-100 active:scale-95">
          ابدئي الآن
        </button>
      </div>
    </header>
  );
}
