import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, ChevronLeft, Baby, Target, Weight, Ruler, BookOpen, PlayCircle, Info } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const weeksData = [
  {
    week: 1,
    title: "الأسبوع الأول",
    size: "فكرة جميلة",
    weight: "0 جرام",
    length: "0 مم",
    description: "فترة الاستعداد والتبويض. جسمكِ يجهز نفسه لاستقبال أغلى هدية.",
    details: "لم يحدث الحمل بعد، ولكن التبويض سيحدث قريباً. اهتمي بتغذيتكِ واشربي الكثير من الماء.",
    tips: ["ابدئي بتناول حمض الفوليك", "تجنبي الأدوية دون استشارة الطبيب"],
    image: "https://images.unsplash.com/photo-1544126592-807daa2b5650?auto=format&fit=crop&q=80&w=400",
    eduContent: "الحمل يبدأ تقنياً من أول يوم في آخر دورة شهرية لكِ. أنتِ الآن في مرحلة التحضير!"
  },
  {
    week: 2,
    title: "الأسبوع الثاني",
    size: "أمل جديد",
    weight: "0 جرام",
    length: "0 مم",
    description: "تحدث الإباضة في هذا الأسبوع. إذا تم الإخصاب، ستبدأ الرحلة العظيمة.",
    details: "تتحرك البويضة الملقحة نحو الرحم ببطء وجمال لتبدأ بالانغراس.",
    tips: ["حافظي على هدوئكِ النفسي", "تناولي طعاماً غنياً بالبروتينات"],
    image: "https://images.unsplash.com/photo-1559757175-7b315e340659?auto=format&fit=crop&q=80&w=400",
    eduContent: "هذا هو الأسبوع الذي تلتقي فيه الحياة بالحياة. معجزة الخلق تبدأ من هنا."
  },
  {
    week: 3,
    title: "الأسبوع الثالث",
    size: "نقطة مضيئة",
    weight: "أقل من 1 جم",
    length: "0.1 مم",
    description: "انقسام الخلايا وتكون النطفة. طفلكِ الآن عبارة عن كرة صغيرة جداً من الطاقة.",
    details: "تبدأ البويضة الملقحة بالاستقرار في منزلها الجديد (الرحم).",
    tips: ["تجنبي الإجهاد البدني الشاق", "أكثري من الخضروات الورقية"],
    image: "https://images.unsplash.com/photo-1516062423079-7ca13cdc7f5a?auto=format&fit=crop&q=80&w=400",
    eduContent: "الجنين يبدأ بتحديد هويته الجينية الفريدة في هذه اللحظة الخاطفة."
  },
  {
    week: 4,
    title: "الأسبوع الرابع",
    size: "بذرة خشخاش",
    weight: "أقل من 1 جم",
    length: "2 مم",
    description: "انغراس الجنين في الرحم وبداية تكون المشيمة. طفلكِ وجد مكانه الآمن.",
    details: "يبدأ إنتاج هرمون الحمل (hCG) الذي يخبر جسمكِ بأن الحياة قد بدأت داخلكِ.",
    tips: ["يمكنكِ إجراء فحص منزلي الآن", "استمري على الفيتامينات بانتظام"],
    image: "https://images.unsplash.com/photo-1617112848923-d287fae1844b?auto=format&fit=crop&q=80&w=400",
    eduContent: "المشيمة، وهي خط الإمداد لطفلكِ، بدأت في التشكل لتعطيه كل ما يحتاجه."
  },
  {
    week: 5,
    title: "الأسبوع الخامس",
    size: "حبة فلفل أسود",
    weight: "أقل من 1 جم",
    length: "3 مم",
    description: "بداية تشكل القلب والجهاز العصبي المركزي. نبض الحياة الأول يستعد للظهور.",
    details: "يبدأ الأنبوب العصبي في التشكل، وهو الذي سيصبح لاحقاً الدماغ والحبل الشوكي.",
    tips: ["الراحة ثم الراحة", "تجنبي الروائح القوية إذا كنتِ تشعرين بالغثيان"],
    image: "https://picsum.photos/seed/week5/400/400",
    eduContent: "قلب طفلكِ هو أول عضو يبدأ في العمل بشكل فعلي. إنه مركز الطاقة!"
  },
  {
    week: 6,
    title: "الأسبوع السادس",
    size: "حبة عدس",
    weight: "أقل من 1 جم",
    length: "5 مم",
    description: "قلب الجنين يبدأ بالنبض بوضوح. صوت الحب الأول يمكن سماعه عبر السونار.",
    details: "تبدأ البراعم الصغيرة التي ستصبح الأطراف بالظهور كأجنحة صغيرة.",
    tips: ["تناولي وجبات خفيفة وموزعة", "اشربي الزنجبيل الدافئ للغثيان"],
    image: "https://picsum.photos/seed/week6/400/400",
    eduContent: "ملامح الوجه تبدأ بالتشكل ببطء شديد كأنها لوحة فنية ترسم بعناية."
  },
  {
    week: 7,
    title: "الأسبوع السابع",
    size: "حبة عنب بري",
    weight: "1 جرام",
    length: "1.2 سم",
    description: "تشكل ملامح الوجه وبراعم الأطراف. طفلكِ بدأ يأخذ شكل الإنسان الصغير.",
    details: "يتضاعف حجم الجنين بسرعة، والدماغ ينمو بوتيرة مذهلة كل دقيقة.",
    tips: ["أكثري من شرب السوائل", "مارسي تمارين التنفس العميق"],
    image: "https://picsum.photos/seed/week7/400/400",
    eduContent: "الذيل الجنيني الصغير بدأ في الاختفاء ليحل محله العمود الفقري المثالي."
  },
  {
    week: 8,
    title: "الأسبوع الثامن",
    size: "حبة توت",
    weight: "1 جرام",
    length: "1.6 سم",
    description: "بداية تكون الأصابع وظهور الأنف. لمسات الجمال والتميز تبدأ في البروز.",
    details: "تبدأ الجفون في التشكل، والقلب ينبض الآن بقوة وثبات لدعم النمو السريع.",
    tips: ["تجنبي الوقوف لفترات طويلة", "راجعي طبيبتكِ للفحص الدوري"],
    image: "https://picsum.photos/seed/week8/400/400",
    eduContent: "أصابع اليدين والقدمين بدأت بالانفصال عن بعضها لتكون قادرة على الحركة لاحقاً."
  },
  {
    week: 9,
    title: "الأسبوع التاسع",
    size: "حبة زيتون",
    weight: "2 جرام",
    length: "2.3 سم",
    description: "بداية حركة الأطراف واختفاء الذيل الجنيني. طفلكِ بدأ يرقص في داخلكِ!",
    details: "العضلات بدأت في التشكل، والجنين يتحرك حركات بسيطة لا تشعرين بها بعد.",
    tips: ["ارفعي قدميكِ عند الجلوس لتقليل التعب", "اختاري ملابس داخلية قطنية مريحة"],
    image: "https://picsum.photos/seed/week9/400/400",
    eduContent: "الجنين يمر الآن بمرحلة تحول كبيرة من مضغة إلى جنين مكتمل الخلقة."
  },
  {
    week: 10,
    title: "الأسبوع العاشر",
    size: "حبة مشمش مجفف",
    weight: "4 جرام",
    length: "3.1 سم",
    description: "اكتمال معظم الأعضاء الحيوية وبداية عملها. المصنع الصغير يعمل بكفاءة.",
    details: "الكلى والكبد والأمعاء بدأت في أداء وظائفها الأساسية لدعم نمو الجسم الداخلي.",
    tips: ["مارسي المشي الخفيف", "تحدثي مع طفلكِ، فهو يشعر بطاقتكِ"],
    image: "https://picsum.photos/seed/week10/400/400",
    eduContent: "بحلول نهاية هذا الأسبوع، يكون طفلكِ قد أنهى المرحلة الحرجة من التطور."
  },
  {
    week: 11,
    title: "الأسبوع الحادي عشر",
    size: "حبة تين",
    weight: "7 جرام",
    length: "4.1 سم",
    description: "الجنين يبدأ بالركل وتتكون براعم الأسنان. الابتسامة القادمة تتجهز من الآن.",
    details: "الجلد لا يزال رقيقاً وشفافاً، ولكن العظام بدأت في التصلب لتصبح أقوى.",
    tips: ["اهتمي بالكالسيوم في غذائكِ", "استعملي كريمات مرطبة لبطنكِ"],
    image: "https://picsum.photos/seed/week11/400/400",
    eduContent: "الركلات الآن عنيفة بالداخل لكنكِ لن تشعري بها بسبب صغر حجم الجنين وكثرة الماء."
  },
  {
    week: 12,
    title: "الأسبوع الثاني عشر",
    size: "حبة ليمون",
    weight: "14 جرام",
    length: "5.4 سم",
    description: "تتشكل الأظافر والكلى تبدأ بإنتاج البول. طفلكِ أصبح كائناً مكتمل التفاصيل.",
    details: "ردود الفعل بدأت تظهر، فالجنين يغلق قبضة يده ويمتص إبهامه أحياناً.",
    tips: ["حان الوقت لمشاركة الخبر الجميل", "استمتعي بنهاية الثلث الأول"],
    image: "https://picsum.photos/seed/week12/400/400",
    eduContent: "هذا الأسبوع يمثل انتصاركِ الأول، فقد تجاوزتِ المرحلة الأكثر حساسية في الحمل."
  },
  {
    week: 13,
    title: "الأسبوع الثالث عشر",
    size: "حبة خوخ",
    weight: "23 جرام",
    length: "7.4 سم",
    description: "اكتمال بصمات الأصابع الفريدة للجنين. هوية طفلكِ الخاصة سُجلت للأبد.",
    details: "تبدأ الأحبال الصوتية في التكون، والجسم يبدأ في النمو ليلحق بحجم الرأس الكبير.",
    tips: ["ابدئي بتمارين كيجل", "تناولي أطعمة غنية بالألياف"],
    image: "https://picsum.photos/seed/week13/400/400",
    eduContent: "طفلكِ الآن يمتلك بصمة يد لا يشبهه فيها أحد في هذا العالم، سبحان الخالق!"
  },
  {
    week: 14,
    title: "الأسبوع الرابع عشر",
    size: "حبة ليمون حامض",
    weight: "43 جرام",
    length: "8.7 سم",
    description: "بداية تمارين التنفس والبلع. الجنين يتدرب ليكون مستعداً للحياة معكِ.",
    details: "الرقبة أصبحت أطول، والذقن ارتفع عن الصدر. ملامح الوجه أصبحت أكثر تناسقاً.",
    tips: ["وضعية نومكِ بدأت تهم", "استمري في تناول الفيتامينات"],
    image: "https://picsum.photos/seed/week14/400/400",
    eduContent: "الكبد يبدأ في إفراز المادة الصفراء، والطحال يبدأ في إنتاج خلايا الدم الحمراء."
  },
  {
    week: 15,
    title: "الأسبوع الخامس عشر",
    size: "حبة تفاح",
    weight: "70 جرام",
    length: "10.1 سم",
    description: "الجلد رقيق جداً والشعر الخفيف يغطي الجسم. طفلكِ يشعر بالدفء والنعومة.",
    details: "العظام تستمر في التصلب، والأذنان وصلتا لمكانهما النهائي على جانبي الرأس.",
    tips: ["راقبي وضعية ظهركِ أثناء الجلوس", "أكثري من شرب الحليب"],
    image: "https://picsum.photos/seed/week15/400/400",
    eduContent: "الجنين يتدرب على حاسة التذوق من خلال السائل المحيط به، فاجعليه حلواً بغذائكِ!"
  },
  {
    week: 16,
    title: "الأسبوع السادس عشر",
    size: "حبة أفوكادو",
    weight: "100 جرام",
    length: "11.6 سم",
    description: "الجهاز العضلي يتقوى ويمكن تحديد جنس الجنين. هل جهزتِ الأسماء؟",
    details: "الرأس أصبح مستقيماً، والعينان تحركتا إلى الأمام. بدأت الرموش والحواجب في النمو.",
    tips: ["تحققي من فقر الدم", "استمتعي بزيادة طاقتكِ في هذا الثلث"],
    image: "https://picsum.photos/seed/week16/400/400",
    eduContent: "في هذا الأسبوع، قد تبدئين بالشعور بحركة تشبه رفرفة الفراشات في بطنكِ."
  },
  {
    week: 17,
    title: "الأسبوع السابع عشر",
    size: "حبة رمان",
    weight: "140 جرام",
    length: "13 سم",
    description: "الدهون تبدأ بالتشكل تحت الجلد للتدفئة. طفلكِ يبني درعه الواقي.",
    details: "الحبل السري ينمو ويصبح أكثر سمكاً وقوة لضمان وصول كل الغذاء للجنين.",
    tips: ["تجنبي النوم على الظهر", "استخدمي وسادة حمل مريحة"],
    image: "https://picsum.photos/seed/week17/400/400",
    eduContent: "الغضاريف اللينة في جسم طفلكِ بدأت تتحول تدريجياً إلى عظام صلبة وقوية."
  },
  {
    week: 18,
    title: "الأسبوع الثامن عشر",
    size: "حبة بطاطس",
    weight: "190 جرام",
    length: "14.2 سم",
    description: "الأم تبدأ بالشعور بحركة الجنين (الرفرفة). ركلات الحب بدأت تصل إليكِ.",
    details: "النظام العصبي ينضج بسرعة، والأوتار في الأذنين بدأت في العمل لسماع الأصوات.",
    tips: ["تحدثي مع طفلكِ بانتظام", "اقرئي له قصصاً هادئة"],
    image: "https://picsum.photos/seed/week18/400/400",
    eduContent: "إذا كان الجنين أنثى، فإن رحمها وقناتي فالوب لديها يتشكلان بالكامل في هذا الأسبوع."
  },
  {
    week: 19,
    title: "الأسبوع التاسع عشر",
    size: "حبة طماطم كبيرة",
    weight: "240 جرام",
    length: "15.3 سم",
    description: "تتطور حواس الجنين (السمع والشم والرؤية). العالم الخارجي بدأ يصل إليه.",
    details: "تتكون طبقة دهنية بيضاء تسمى 'الطلاء الجبني' لحماية جلد الجنين من السوائل.",
    tips: ["رطبي جلدكِ بزبدة الكاكاو", "تناولي أطعمة غنية بالزنك"],
    image: "https://picsum.photos/seed/week19/400/400",
    eduContent: "الدماغ يخصص مناطق محددة لكل حاسة من الحواس الخمس في هذه المرحلة."
  },
  {
    week: 20,
    title: "الأسبوع العشرون",
    size: "حبة موز",
    weight: "300 جرام",
    length: "25.6 سم",
    description: "الجنين يبتلع السائل لتحفيز الجهاز الهضمي. أنتِ الآن في منتصف الطريق!",
    details: "الجهاز الهضمي بدأ بإنتاج 'العقي' (أول براز للطفل)، وهو علامة على الصحة الجيدة.",
    tips: ["احتفلي بمنتصف الرحلة", "ابدئي بتخيل شكل غرفته"],
    image: "https://picsum.photos/seed/week20/400/400",
    eduContent: "طفلكِ الآن يمتلك دورات نوم ومنبهات استيقاظ خاصة به، قد لا تتفق مع نومكِ!"
  },
  {
    week: 21,
    title: "الأسبوع الحادي والعشرون",
    size: "حبة جزر كبيرة",
    weight: "360 جرام",
    length: "26.7 سم",
    description: "تزداد قوة الركلات وتصبح أكثر انتظاماً. طفلكِ يخبركِ بوجوده بقوة.",
    details: "الجنين يتحرك بحرية كبيرة الآن لأن المساحة لا تزال تسمح له بالدوران والشقلبة.",
    tips: ["سجلي أوقات حركة الجنين", "تناولي وجبات خفيفة قبل النوم"],
    image: "https://picsum.photos/seed/week21/400/400",
    eduContent: "حواجب طفلكِ ورموشه تكتمل تماماً الآن، وتعطي وجهه ملامحه الرقيقة."
  },
  {
    week: 22,
    title: "الأسبوع الثاني والعشرون",
    size: "حبة بابايا",
    weight: "430 جرام",
    length: "27.8 سم",
    description: "ظهور الحواجب والرموش بشكل كامل. نظرة طفلكِ الجمالية تكتمل.",
    details: "تستمر الحواس في التطور، حيث يمكن للجنين الآن استشعار الضوء القوي المسلط على بطنكِ.",
    tips: ["استخدمي إضاءة هادئة", "تجنبي الضوضاء المفاجئة"],
    image: "https://picsum.photos/seed/week22/400/400",
    eduContent: "البنكرياس، المسؤول عن إنتاج الهرمونات، يتطور بسرعة في هذا الأسبوع."
  },
  {
    week: 23,
    title: "الأسبوع الثالث والعشرون",
    size: "حبة مانجو كبيرة",
    weight: "500 جرام",
    length: "28.9 سم",
    description: "بداية تكوين صبغة الجلد وتغير لونه للوردي. الجمال يتجسد في التفاصيل.",
    details: "الرئتان مستمرتان في التطور، والجنين يقوم بحركات تنفسية أكثر تعقيداً وقوة.",
    tips: ["تناولي أطعمة غنية بالحديد", "خففي من الكافيين قدر الإمكان"],
    image: "https://picsum.photos/seed/week23/400/400",
    eduContent: "أذنا طفلكِ قادرتان الآن على تمييز صوتكِ وصوت والده بوضوح مذهل!"
  },
  {
    week: 24,
    title: "الأسبوع الرابع والعشرون",
    size: "ذرة حلوة",
    weight: "600 جرام",
    length: "30 سم",
    description: "الرئتان تبدآن بالاستعداد للتنفس المستقبلي. التحضير لشهيق الحياة الأول.",
    details: "يبدأ إنتاج مادة 'السيرفاكتانت' التي تساعد الرئتين على التمدد والعمل بعد الولادة.",
    tips: ["أجري فحص سكر الحمل", "انتبهي لأي تورم في قدميكِ"],
    image: "https://picsum.photos/seed/week24/400/400",
    eduContent: "طفلكِ الآن يمتلك فرصة كبيرة للنجاة إذا وُلد مبكراً بفضل الرعاية الطبية الحديثة."
  },
  {
    week: 25,
    title: "الأسبوع الخامس والعشرون",
    size: "حبة قرنبيط",
    weight: "660 جرام",
    length: "34.6 سم",
    description: "الجنين يفتح عينيه ويستجيب للضوء الخارجي. هو الآن ينظر نحو المستقبل.",
    details: "تبدأ الشعيرات الدموية تحت الجلد في الامتلاء بالدم، مما يعطي الجنين لوناً وردياً.",
    tips: ["العبي بالضوء مع طفلكِ على بطنكِ", "اهتمي بالكالسيوم للعظام"],
    image: "https://picsum.photos/seed/week25/400/400",
    eduContent: "رد فعل طفلكِ تجاه الضوء يعني أن نظامه العصبي البصري يعمل بكفاءة."
  },
  {
    week: 26,
    title: "الأسبوع السادس والعشرون",
    size: "رأس كرنب",
    weight: "760 جرام",
    length: "35.6 سم",
    description: "الدماغ يزداد تعقيداً ويستجيب للمس والأصوات. طفلكِ أصبح ذكياً ومتفاعلاً.",
    details: "قوة السمع تزداد، وقد يرتجف الجنين أو يركل إذا سمع صوتاً قوياً ومفاجئاً.",
    tips: ["استمعي لقرآن أو موسيقى هادئة", "تجنبي الأماكن المزدحمة بالضجيج"],
    image: "https://picsum.photos/seed/week26/400/400",
    eduContent: "الجنين يتدرب الآن على فتح وإغلاق جفونه بانتظام، تمرين رائع للعينين!"
  },
  {
    week: 27,
    title: "الأسبوع السابع والعشرون",
    size: "حبة باذنجان",
    weight: "900 جرام",
    length: "36.6 سم",
    description: "الرئتان والجهاز العصبي في نضج مستمر. جنينكِ يجهز نفسه للعالم الخارجي.",
    details: "تبدأ دورات النوم في التحسن، وقد تلاحظين أوقاتاً محددة يكون فيها طفلكِ نشيطاً جداً.",
    tips: ["مارسي تمارين التنفس العميق", "راقبي نمط الركلات"],
    image: "https://picsum.photos/seed/week27/400/400",
    eduContent: "أهلاً بكِ في الثلث الأخير! هذه هي المرحلة الحاسمة والجميلة في رحلتكِ."
  },
  {
    week: 28,
    title: "الأسبوع الثامن والعشرون",
    size: "حبة خس كبيرة",
    weight: "1 كجم",
    length: "37.6 سم",
    description: "بداية دورات النوم والاستيقاظ المستقرة. طفلكِ يدخل مرحلة الأحلام الآن.",
    details: "الدماغ يبدأ في تكوين التلافيف والشقوق التي تزيد من قدراته الذهنية والمعالجة.",
    tips: ["اخفظي من تناول السكريات", "استشيري الطبيب عن حقنة الفصيلة"],
    image: "https://picsum.photos/seed/week28/400/400",
    eduContent: "علماء الأجنة يعتقدون أن الجنين في هذه المرحلة يبدأ بالحلم! يا ترى بماذا يحلم؟"
  },
  {
    week: 29,
    title: "الأسبوع التاسع والعشرون",
    size: "حبة يقطين صغيرة",
    weight: "1.1 كجم",
    length: "38.6 سم",
    description: "تزداد حاجة الجنين للكالسيوم لتقوية العظام. الهيكل العظمي يصبح درعاً قوياً.",
    details: "الرأس ينمو ليوفر مساحة أكبر للدماغ النامي بسرعة، والحواس أصبحت حادة جداً.",
    tips: ["أكثري من الألبان والأجبان", "تجنبي النوم على ظهركِ تماماً"],
    image: "https://picsum.photos/seed/week29/400/400",
    eduContent: "الجنين يستطيع الآن تمييز الفرق بين ضوء الشمس الاصطناعي والضوء الطبيعي."
  },
  {
    week: 30,
    title: "الأسبوع الثلاثون",
    size: "حبة خيار كبيرة",
    weight: "1.3 كجم",
    length: "39.9 سم",
    description: "الجنين يبدأ بإنتاج خلايا الدم الحمراء بنفسه. المعمل الخاص به بدأ بالعمل.",
    details: "الجهاز العصبي أصبح قادراً على تنظيم درجة حرارة الجسم بفعالية أكبر من قبل.",
    tips: ["ارفعي قدميكِ لتقليل التورم", "قللي من الأطعمة المسببة للحرقان"],
    image: "https://picsum.photos/seed/week30/400/400",
    eduContent: "نخاع العظم هو الذي يتولى الآن إنتاج خلايا الدم، وهي وظيفة حيوية ومستمرة."
  },
  {
    week: 31,
    title: "الأسبوع الحادي والثلاثون",
    size: "حبة شمام صغيرة",
    weight: "1.5 كجم",
    length: "41.1 سم",
    description: "نمو سريع للدماغ وتطور مهارات التركيز. طفلكِ الصغير يتجهز بذكاء.",
    details: "تزداد طبقة الدهون تحت الجلد، مما يجعل الجنين يبدو أكثر امتلاءً وجمالاً يوماً بعد يوم.",
    tips: ["تحركي ببطء وهدوء", "ابدئي بتجهيز حقيبة الولادة"],
    image: "https://picsum.photos/seed/week31/400/400",
    eduContent: "في هذا الوقت، قد تلاحظين أن طفلكِ يتفاعل مع لمساتكِ لبطنكِ بشكل مباشر."
  },
  {
    week: 32,
    title: "الأسبوع الثاني والثلاثون",
    size: "حبة جوز هند",
    weight: "1.7 كجم",
    length: "42.4 سم",
    description: "تدريبات على التنفس بعمق استعداداً للولادة. الصدر يرتفع وينخفض بانتظام.",
    details: "أظافر طفلكِ قد اكتملت الآن، وقد يحتاج لتقليمها فور ولادته للحفاظ على جلده.",
    tips: ["استعدي لغرفة الطفل", "احصلي على قسط وافر من النوم"],
    image: "https://picsum.photos/seed/week32/400/400",
    eduContent: "معظم الأجنة يتخذون الآن وضعية الرأس للأسفل استعداداً لرحلة الخروج."
  },
  {
    week: 33,
    title: "الأسبوع الثالث والثلاثون",
    size: "حبة أناناس",
    weight: "1.9 كجم",
    length: "43.7 سم",
    description: "الجهاز المناعي يتقوى عبر أجسام الأم المضادة. حماية طفلكِ تبدأ منكِ.",
    details: "المساحة أصبحت ضيقة جداً للجنين، لذا ستشعرين بركلات قوية بدلاً من الشقلبات.",
    tips: ["راقبي حركة الجنين بتركيز", "اشربي سوائل كثيرة"],
    image: "https://picsum.photos/seed/week33/400/400",
    eduContent: "الجمجمة لا تزال لينة ومنفصلة لتسهيل مرور الرأس بسلام خلال عملية الولادة."
  },
  {
    week: 34,
    title: "الأسبوع الرابع والثلاثون",
    size: "حبة يقطين متوسطة",
    weight: "2.1 كجم",
    length: "45 سم",
    description: "الجهاز الهضمي جاهز تماماً لمعالجة الحليب. المعدة الصغيرة تنتظر أول رضعة.",
    details: "نظام المناعة يواصل اكتساب القوة، والجنين يتدرب على حركات المص والبلع.",
    tips: ["شاركي مشاعركِ مع زوجكِ", "تعلمي عن تقنيات الرضاعة الطبيعية"],
    image: "https://picsum.photos/seed/week34/400/400",
    eduContent: "الجنين يستطيع الآن تمييز الأصوات المألوفة والموسيقى التي كان يسمعها بانتظام."
  },
  {
    week: 35,
    title: "الأسبوع الخامس والثلاثون",
    size: "حبة رقي (بطيخ) صغيرة",
    weight: "2.4 كجم",
    length: "46.2 سم",
    description: "الكلى والكبد في حالة عمل تامة لتنقية الجسم. الأجهزة الداخلية نضجت تماماً.",
    details: "اكتمال نمو معظم الأجهزة الحيوية، والدهون يستمر تراكمها في مناطق الأرداف والكتفين.",
    tips: ["تجنبي الجلوس الطويل", "مارسي تمارين الاسترخاء"],
    image: "https://picsum.photos/seed/week35/400/400",
    eduContent: "99% من الأجنة الذين يولدون في هذا الأسبوع يستطيعون النجاة دون مشاكل كبرى."
  },
  {
    week: 36,
    title: "الأسبوع السادس والثلاثون",
    size: "باقة خس كبيرة",
    weight: "2.6 كجم",
    length: "47.4 سم",
    description: "اتخاذ وضعية الولادة النهائية (الرأس نحو الحوض). طفلكِ عند خط البداية.",
    details: "قد تشعرين بانخفاض البطن للأسفل، مما يسهل عليكِ التنفس ولكن يزيد من ضغط الحوض.",
    tips: ["جهزي سيارتكِ لموعد الولادة", "تأكدي من توفر أغراض الفندق السريع"],
    image: "https://picsum.photos/seed/week36/400/400",
    eduContent: "في هذا الأسبوع، يُعتبر الجنين 'مبكر النضج' ومستعداً للظهور في أي لحظة."
  },
  {
    week: 37,
    title: "الأسبوع السابع والثلاثون",
    size: "حبة كرفس كبيرة",
    weight: "2.8 كجم",
    length: "48.6 سم",
    description: "اكتمال نمو الرئتين (حمل مكتمل طبياً). طفلكِ أصبح جاهزاً لاستنشاق الهواء.",
    details: "تستمر الدهون في التراكم بمعدل 14 جراماً يومياً لضمان الدفء بعد الولادة.",
    tips: ["مارسي المشي اللطيف", "ابحثي عن علامات الطلق الحقيقي"],
    image: "https://picsum.photos/seed/week37/400/400",
    eduContent: "تهانينا! طبياً، أنتِ الآن قد أتممتِ حملكِ والجنين جاهز تماماً للحياة الخارجية."
  },
  {
    week: 38,
    title: "الأسبوع الثامن والثلاثون",
    size: "حبة كراث كبيرة",
    weight: "3 كجم",
    length: "49.8 سم",
    description: "تساقط الشعر الناعم الذي كان يغطي الجسم. طفلكِ يغسل نفسه استعداداً للقاء.",
    details: "تستمر الأمعاء في مراكمة 'العقي' الذي سيخرج في أول تغيير للحفاض بعد الولادة.",
    tips: ["استمتعي بلحظاتكِ الأخيرة الهادئة", "تحققي من جاهزية البيت"],
    image: "https://picsum.photos/seed/week38/400/400",
    eduContent: "لون عيني طفلكِ عند الولادة قد يتغير لاحقاً، لذا لا تتعجلي في تحديد لونهما!"
  },
  {
    week: 39,
    title: "الأسبوع التاسع والثلاثون",
    size: "بطيخة صيفية",
    weight: "3.2 كجم",
    length: "50.7 سم",
    description: "المشيمة تستمر بإمداد الجنين بالمضادات الحيوية. درع حماية إضافي قبل الخروج.",
    details: "عنق الرحم يبدأ في التوسع والترقق استعداداً للمخاض المرتقب في أي ساعة.",
    tips: ["الراحة النفسية هي الأهم الآن", "كوني مستعدة دائماً للذهاب للمستشفى"],
    image: "https://picsum.photos/seed/week39/400/400",
    eduContent: "يستمر طفلكِ في اكتساب القليل من الوزن لضمان مخزون طاقة كافٍ بعد الولادة."
  },
  {
    week: 40,
    title: "الأسبوع الأربعون",
    size: "بطيخة ناضجة",
    weight: "3.5 كجم",
    length: "51.2 سم",
    description: "يوم اللقاء المنتظر! طفلكِ مكتمل النمو تماماً وبانتظار ساعة الصفر.",
    details: "الموعد المحدد هو مجرد تقدير، لا تقلقي إذا تأخر طفلكِ لبضعة أيام أخرى.",
    tips: ["حافظي على هدوئكِ التام", "أنتِ بطلة وستنجحين في هذا!"],
    image: "https://picsum.photos/seed/week40/400/400",
    eduContent: "فقط 5% من النساء يلدن في موعدهن بالضبط. طفلكِ سيختار وقته المثالي للقائكِ."
  }
];

export default function WeeklyProgress() {
  const { patient } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(6); // Default to week 27 (index 6)

  useEffect(() => {
    if (patient?.pregnancyStartDate) {
      const lmp = new Date(patient.pregnancyStartDate);
      const today = new Date();
      const diffDays = Math.floor((today.getTime() - lmp.getTime()) / (1000 * 60 * 60 * 24));
      const currentWeeks = Math.floor(diffDays / 7);
      
      // Find closest week in our data
      const index = weeksData.findIndex(w => w.week >= currentWeeks);
      if (index !== -1) {
        setCurrentIndex(index);
      }
    }
  }, [patient]);

  const currentWeek = weeksData[currentIndex];

  const next = () => setCurrentIndex((prev) => (prev + 1) % weeksData.length);
  const prev = () => setCurrentIndex((prev) => (prev - 1 + weeksData.length) % weeksData.length);

  return (
    <section id="progress" className="py-24 space-y-12">
      <div className="container mx-auto px-4 text-right" dir="rtl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">تطور جنينكِ أسبوعاً بأسبوع</h2>
          <p className="text-gray-500">محتوى تعليمي مبسط وموثوق لمتابعة مراحل نمو طفلكِ الجميل.</p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            
            {/* Image Content */}
            <div className="space-y-6">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentWeek.week}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="relative aspect-square rounded-[3.5rem] overflow-hidden border-8 border-white shadow-2xl shadow-pink-100"
                >
                  <img 
                    src={currentWeek.image} 
                    alt={currentWeek.title} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  <div className="absolute bottom-8 right-8 text-white text-right">
                    <p className="text-sm opacity-90 font-bold mb-1">تخيلي حجم طفلكِ كأنه</p>
                    <h4 className="text-4xl font-black">{currentWeek.size}</h4>
                  </div>
                </motion.div>
              </AnimatePresence>

              <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-lg text-right">
                <h3 className="font-bold text-gray-900 text-xl mb-4">نصيحة الأسبوع</h3>
                <div className="space-y-3">
                  {currentWeek.tips.map((tip, i) => (
                    <div key={i} className="flex items-center gap-3 flex-row-reverse bg-brand-50/50 p-4 rounded-2xl">
                      <div className="w-2 h-2 rounded-full bg-brand-500" />
                      <p className="text-gray-700 font-medium">{tip}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Information Content */}
            <div className="space-y-8">
              <div className="flex items-center justify-between flex-row-reverse">
                <div className="flex items-center gap-3 flex-row-reverse">
                  <div className="w-12 h-12 bg-brand-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-brand-100">
                    <Baby size={24} />
                  </div>
                  <div className="text-right">
                    <h3 className="text-3xl font-black bg-clip-text text-transparent bg-gradient-to-r from-brand-600 to-pink-500 drop-shadow-sm">
                      {currentWeek.title}
                    </h3>
                    <p className="text-xs text-brand-500 font-bold uppercase tracking-wider">خريطة تطور الجنين</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={prev} className="w-10 h-10 rounded-full bg-white border border-gray-100 hover:bg-brand-50 transition-all flex items-center justify-center text-gray-400 hover:text-brand-500 shadow-sm"><ChevronRight size={20} /></button>
                  <button onClick={next} className="w-10 h-10 rounded-full bg-white border border-gray-100 hover:bg-brand-50 transition-all flex items-center justify-center text-gray-400 hover:text-brand-500 shadow-sm"><ChevronLeft size={20} /></button>
                </div>
              </div>

              {/* Stats Bar */}
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-blue-50 p-4 rounded-3xl text-center">
                  <Ruler className="mx-auto text-blue-500 mb-2" size={20} />
                  <p className="text-[10px] text-blue-400 font-bold uppercase">الطول</p>
                  <p className="font-black text-blue-900 underline decoration-blue-200">{currentWeek.length}</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-3xl text-center">
                  <Weight className="mx-auto text-purple-500 mb-2" size={20} />
                  <p className="text-[10px] text-purple-400 font-bold uppercase">الوزن</p>
                  <p className="font-black text-purple-900 underline decoration-purple-200">{currentWeek.weight}</p>
                </div>
                <div className="bg-green-50 p-4 rounded-3xl text-center">
                  <Target className="mx-auto text-green-500 mb-2" size={20} />
                  <p className="text-[10px] text-green-400 font-bold uppercase">المرحلة</p>
                  <p className="font-black text-green-900 underline decoration-green-200">{currentWeek.week <= 12 ? '1' : currentWeek.week <= 26 ? '2' : '3'}</p>
                </div>
              </div>

              <div className="bg-white p-8 rounded-[2.5rem] border border-gray-50 shadow-xl shadow-pink-100/20 text-right">
                <h4 className="font-bold text-gray-900 mb-4 flex items-center gap-2 flex-row-reverse">
                  <Info className="text-brand-500" size={18} />
                  ماذا يحدث الآن؟
                </h4>
                <p className="text-gray-600 leading-relaxed text-lg mb-6">{currentWeek.description}</p>
                <div className="p-6 bg-pink-50/50 rounded-3xl border border-brand-100 text-brand-900 text-sm italic">
                  {currentWeek.details}
                </div>
              </div>

              {/* Simplified Edu Cards */}
              <div className="bg-indigo-500 p-8 rounded-[2.5rem] text-white overflow-hidden relative group text-right">
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-4 flex-row-reverse">
                    <BookOpen size={24} className="opacity-80" />
                    <h4 className="font-black text-xl">معلومة تهمكِ</h4>
                  </div>
                  <p className="text-indigo-50 leading-relaxed font-medium">
                    {currentWeek.eduContent}
                  </p>
                </div>
                <BookOpen className="absolute -bottom-4 -left-4 w-32 h-32 text-white/10 -rotate-12 group-hover:scale-110 transition-transform" />
              </div>

            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
