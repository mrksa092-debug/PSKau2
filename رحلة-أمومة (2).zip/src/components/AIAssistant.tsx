import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X, Send, Bot, User, Loader2 } from 'lucide-react';
import { getNouraResponse } from '../services/aiService';
import { useAuth } from '../contexts/AuthContext';

export default function AIAssistant() {
  const { patient } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([
    { role: 'ai', text: 'مرحباً بكِ نورة! أنا "نورة"، مساعدتكِ الذكية. كيف يمكنني مساعدتكِ اليوم في رحلة حملكِ؟' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading || !patient) return;

    const userMessage = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      const response = await getNouraResponse(userMessage, patient);
      setMessages(prev => [...prev, { role: 'ai', text: response || 'عذراً، لم أستطع فهم ذلك.' }]);
    } catch (err) {
      console.error("AI Assistant Error:", err);
      setMessages(prev => [...prev, { role: 'ai', text: 'عذراً، حدث خطأ ما. يرجى المحاولة مرة أخرى.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Button */}
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-8 right-8 w-16 h-16 bg-brand-600 text-white rounded-full flex items-center justify-center shadow-2xl shadow-brand-400 hover:scale-110 active:scale-95 transition-all z-50 overflow-hidden"
      >
        <MessageCircle size={28} />
        <motion.div 
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute inset-0 bg-white/20"
        />
      </button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            className="fixed bottom-28 right-8 w-[90vw] md:w-[400px] h-[550px] bg-white rounded-[2.5rem] shadow-2xl flex flex-col z-50 border border-pink-50 overflow-hidden"
          >
            {/* Header */}
            <div className="bg-brand-600 p-6 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                  <Bot size={24} />
                </div>
                <div>
                  <h3 className="font-bold">مساعد أمومة AI</h3>
                  <p className="text-xs opacity-80">متصل الآن لمساعدتكِ</p>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="w-8 h-8 flex items-center justify-center hover:bg-white/10 rounded-full"
              >
                <X size={20} />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-grow overflow-y-auto p-6 space-y-4 bg-gray-50/50">
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}>
                  <div className={`max-w-[80%] p-4 rounded-2xl flex gap-3 ${
                    msg.role === 'user' 
                      ? 'bg-brand-500 text-white rounded-br-none' 
                      : 'bg-white text-gray-800 shadow-sm border border-gray-100 rounded-bl-none'
                  }`}>
                    {msg.role === 'ai' && <Bot size={18} className="shrink-0 mt-1 text-brand-500" />}
                    <p className="text-sm leading-relaxed">{msg.text}</p>
                    {msg.role === 'user' && <User size={18} className="shrink-0 mt-1" />}
                  </div>
                </div>
              ))}
              {isLoading && !messages[messages.length-1].text && (
                <div className="flex justify-end">
                  <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-2">
                    <Loader2 size={16} className="animate-spin text-brand-500" />
                    <span className="text-xs text-gray-400">يفكر المساعد...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 bg-white border-t border-gray-100">
              <div className="flex gap-2">
                <button 
                  onClick={handleSend}
                  disabled={isLoading || !input.trim()}
                  className="bg-brand-500 text-white w-12 h-12 rounded-xl flex items-center justify-center disabled:opacity-50 hover:bg-brand-600 transition-all shrink-0"
                >
                  <Send size={20} className="rotate-180" />
                </button>
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="اسألي أي شيء..."
                  className="flex-grow bg-gray-50 border-none rounded-xl px-4 text-sm focus:ring-1 focus:ring-brand-500 outline-none text-right"
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
