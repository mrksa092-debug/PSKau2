import React, { createContext, useContext, useState, useEffect } from 'react';
import { auth, db, handleFirestoreError } from '../services/firebase';
import { signInAnonymously, onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp, collection, getDocs } from 'firebase/firestore';

interface LabResult {
  id: string;
  testName: string;
  date: string;
  result: string;
  unit: string;
  range: string;
  status: 'normal' | 'low' | 'high';
}

interface MedicalReport {
  id: string;
  title: string;
  date: string;
  doctor: string;
  summary: string;
  fileUrl?: string;
  status?: 'attended' | 'upcoming' | 'missed';
}

interface Message {
  id: string;
  sender: 'doctor' | 'patient';
  text: string;
  timestamp: string;
}

interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  instructions: string;
  sideEffects: string;
}

interface Patient {
  fileNumber: string;
  name: string;
  dob: string;
  age: number;
  pregnancyStartDate: string;
  expectedDeliveryDate: string;
  bloodType: string;
  hospitalName: string;
  gravida: number;
  parity: number;
  pastMedicalHistory: string[];
  familyHistory: string[];
  medicalReports?: MedicalReport[];
  labResults?: LabResult[];
  messages?: Message[];
  medications?: Medication[];
}

interface AuthContextType {
  user: User | null;
  patient: Patient | null;
  loading: boolean;
  login: (fileNumber: string, dob: string) => Promise<void>;
  logout: () => Promise<void>;
  updatePatient: (data: Partial<Patient>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [patient, setPatient] = useState<Patient | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        try {
          const userDoc = await getDoc(doc(db, 'users', u.uid));
          if (userDoc.exists()) {
            const fileNumber = userDoc.data().patientFileNumber;
            const patientDoc = await getDoc(doc(db, 'patients', fileNumber));
            if (patientDoc.exists()) {
              setPatient(patientDoc.data() as Patient);
            }
          }
        } catch (err) {
          console.error("Error fetching linked patient:", err);
        }
      } else {
        setPatient(null);
      }
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const login = async (fileNumber: string, dob: string) => {
    setLoading(true);
    try {
      // 1. Authentication
      let currentUser = auth.currentUser;
      if (!currentUser) {
        try {
          const cred = await signInAnonymously(auth);
          currentUser = cred.user;
        } catch (authErr: any) {
          console.warn("Auth failed, continuing for demo check:", authErr);
          if (fileNumber !== '00000001') throw authErr;
        }
      }

      const patientRef = doc(db, 'patients', fileNumber);

      // 2. Handle Demo Account (Quick Login)
      if (fileNumber === '00000001') {
        if (dob !== '1992-05-12') {
          throw new Error('تاريخ الميلاد غير صحيح لرقم الملف التجريبي.');
        }

        const demoPatient: Patient = {
          fileNumber: '00000001',
          name: "نورة القحطاني",
          dob: '1992-05-12',
          age: 34,
          pregnancyStartDate: new Date(Date.now() - 189 * 24 * 60 * 60 * 1000).toISOString(),
          expectedDeliveryDate: new Date(Date.now() + 91 * 24 * 60 * 60 * 1000).toISOString(),
          bloodType: "A-",
          hospitalName: "مستشفى الملك فيصل التخصصي",
          gravida: 3,
          parity: 2,
          pastMedicalHistory: ['حساسية ضد حبوب اللقاح', 'فقر دم خفيف في الحمل السابق'],
          familyHistory: ['ارتفاع ضغط الدم (الأم)', 'مرض السكري (الخال)'],
          medicalReports: [
            {
              id: 'rep1',
              title: 'الزيارة الأولى وتأكيد الحمل (الأسبوع 8)',
              date: new Date(Date.now() - 133 * 24 * 60 * 60 * 1000).toISOString(),
              doctor: 'د. هند المنصور',
              summary: 'تم التحقق من كيس الحمل ونبض الجنين (158 نبضة/دقيقة). القياسات مطابقة للأسبوع الثامن. تم صرف حمض الفوليك وفيتامين د. التاريخ المتوقع للولادة: 23 يوليو 2026.',
              status: 'attended'
            },
            {
              id: 'rep2',
              title: 'فحص الشفافية القفوية (الأسبوع 12)',
              date: new Date(Date.now() - 105 * 24 * 60 * 60 * 1000).toISOString(),
              doctor: 'د. هند المنصور',
              summary: 'قياس الشفافية القفوية (NT) طبيعي جداً (1.3 ملم). عظمة الأنف واضحة. تم إجراء سحب دم لفحص الكروموسومات (NIPT) والنتائج سليمة ولله الحمد.',
              status: 'attended'
            },
            {
              id: 'rep3',
              title: 'الأشعة التفصيلية - مورفولوجيا (الأسبوع 20)',
              date: new Date(Date.now() - 49 * 24 * 60 * 60 * 1000).toISOString(),
              doctor: 'قسم الأشعة المتخصص',
              summary: 'فحص شامل لأعضاء الجنين: الدماغ، القلب (أربع حجرات)، الكلى، العمود الفقري، والأطراف. جميعها تنمو بشكل طبيعي. المشيمة خلفية وعالية. جنس الجنين: أنثى.',
              status: 'attended'
            },
            {
              id: 'rep4',
              title: 'متابعة النمو واختبار الجلوكوز (الأسبوع 26)',
              date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
              doctor: 'د. هند المنصور',
              summary: 'نمو الجنين متناسق مع عمره. الوزن التقديري: 920 جرام. نتيجة اختبار تحمل السكر (OGTT) طبيعية. لا توجد زلال في البول. تم البدء في تناول مكمل الحديد.',
              status: 'attended'
            },
            {
              id: 'rep5',
              title: 'فحص سونار النمو المتوقع (الأسبوع 32)',
              date: new Date(Date.now() + 35 * 24 * 60 * 60 * 1000).toISOString(),
              doctor: 'د. هند المنصور',
              summary: 'موعد مستقبلي لمتابعة وزن الجنين وكمية السائل الأمينوسي ووضعية المشيمة قبل دخول الشهر التاسع.',
              status: 'upcoming'
            }
          ],
          labResults: [
            { id: 'lab1', testName: 'CBC (صورة الدم)', date: '2026-04-10', result: '11.8', unit: 'g/dL', range: '11.0 - 15.0', status: 'normal' },
            { id: 'lab_iron', testName: 'Ferritin (مخزون الحديد)', date: '2026-04-10', result: '38', unit: 'ng/mL', range: '30 - 150', status: 'normal' },
            { id: 'lab2', testName: 'GTT (تحميل الجلوكوز)', date: '2026-04-15', result: '135', unit: 'mg/dL', range: '< 140', status: 'normal' },
            { id: 'lab3', testName: 'فيتامين د (Vitamin D)', date: '2026-02-15', result: '22', unit: 'ng/mL', range: '30 - 100', status: 'low' },
            { id: 'lab4', testName: 'تحليل البول الروتيني', date: '2026-04-15', result: 'Normal', unit: '-', range: '-', status: 'normal' },
            { id: 'lab_hiv', testName: 'فحص HIV', date: '2026-01-10', result: 'Negative', unit: '-', range: '-', status: 'normal' }
          ],
          medications: [
            {
              id: 'med1',
              name: 'Elevit (إليفيت)',
              dosage: '800 mcg',
              frequency: 'مرة واحدة يومياً',
              instructions: 'يؤخذ مع الأكل لزيادة الامتصاص وتقليل الغثيان.',
              sideEffects: 'تغير في لون البول (طبيعي).'
            },
            {
              id: 'med2',
              name: 'Feroglobin (فيروغلوبين)',
              dosage: '30 mg',
              frequency: 'مرة واحدة يومياً',
              instructions: 'يفضل أخذه مع عصير برتقال لزيادة الامتصاص.',
              sideEffects: 'إمساك بسيط.'
            }
          ],
          messages: [
            { id: 'm1', sender: 'doctor', text: 'أهلاً نورة، نتائج تحاليل سكر الحمل (OGTT) جاءت طبيعية ولله الحمد.', timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString() },
            { id: 'm2', sender: 'patient', text: 'الحمد لله دكتورة. هل أحتاج للمتابعة بخصوص فيتامين د؟', timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString() },
            { id: 'm3', sender: 'doctor', text: 'نعم، استمري على الجرعة الحالية وسنعيد الفحص بعد شهر بإذن الله.', timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString() }
          ]
        };

        setPatient(demoPatient);
        
        // Background sync to DB
        if (currentUser) {
          setDoc(patientRef, demoPatient, { merge: true }).catch(e => console.warn("Sync failed:", e));
          setDoc(doc(db, 'users', currentUser.uid), {
            patientFileNumber: fileNumber,
            createdAt: serverTimestamp()
          }, { merge: true }).catch(e => console.warn("User link failed:", e));
        }

        setLoading(false);
        return;
      }

      // 3. Handle Regular User
      const patientSnap = await getDoc(patientRef);
      if (patientSnap.exists()) {
        const data = patientSnap.data() as Patient;
        if (data.dob !== dob) {
          throw new Error('تاريخ الميلاد غير مطابق لرقم الملف.');
        }
        setPatient(data);

        if (currentUser) {
          await setDoc(doc(db, 'users', currentUser.uid), {
            patientFileNumber: fileNumber,
            createdAt: serverTimestamp()
          }, { merge: true });
        }
      } else {
        throw new Error('رقم الملف غير موجود في النظام.');
      }

    } catch (err: any) {
      handleFirestoreError(err, 'get', `patients/${fileNumber}`);
    } finally {
      setLoading(false);
    }
  };

  const updatePatient = async (data: Partial<Patient>) => {
    if (!patient) return;
    const newPatient = { ...patient, ...data };
    setPatient(newPatient);
    if (user) {
      try {
        await setDoc(doc(db, 'patients', patient.fileNumber), newPatient, { merge: true });
      } catch (err) {
        console.error("Error updating patient in DB:", err);
      }
    }
  };

  const logout = async () => {
    await auth.signOut();
    setPatient(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, patient, loading, login, logout, updatePatient }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
